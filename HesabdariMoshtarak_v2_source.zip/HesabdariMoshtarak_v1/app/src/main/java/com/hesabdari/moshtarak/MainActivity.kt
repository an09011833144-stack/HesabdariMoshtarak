package com.hesabdari.moshtarak

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.sqlite.*
import android.graphics.Color
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var db: LedgerDb
    private lateinit var root: LinearLayout
    private var branch = "حرم"

    override fun onCreate(b: Bundle?) { super.onCreate(b); db = LedgerDb(this); showHome() }

    private fun base(title: String) {
        root = findViewById(R.id.root); root.removeAllViews()
        val t = TextView(this).apply { text = title; textSize = 25f; setTextColor(Color.DKGRAY); gravity = Gravity.RIGHT; setPadding(0, 0, 0, 20) }
        root.addView(t)
    }
    private fun btn(text: String, action: () -> Unit) { val b=Button(this); b.text=text; b.setOnClickListener{action()}; root.addView(b, LinearLayout.LayoutParams(-1,56).also{it.setMargins(0,5,0,5)}) }
    private fun field(hint:String) = EditText(this).apply { this.hint=hint; textSize=17f; gravity=Gravity.RIGHT }
    private fun moneyInput(hint:String="مبلغ به تومان") = EditText(this).apply { this.hint=hint; inputType=2; textSize=18f; gravity=Gravity.RIGHT }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun fmt(n:Long)=String.format("%,d",n)

    private fun showHome(){
        base("حسابداری مشترک")
        val info=TextView(this).apply{text="واحد پول: تومان\nدو شعبه: آرایشی و حرم";gravity=Gravity.RIGHT;setPadding(0,0,0,15)};root.addView(info)
        btn("🏪 آرایشی"){branch="آرایشی";showBranch()}; btn("🕌 حرم"){branch="حرم";showBranch()}; btn("📊 گزارش کلی"){showReport()}; btn("📜 همه تراکنش‌ها"){showHistory()}
    }
    private fun showBranch(){
        base(branch)
        btn("💰 ثبت فروش روزانه"){showSales()}; btn("💸 ثبت هزینه"){showExpense()}; btn("🧾 خرید نسیه از فروشنده"){showPurchase()}; btn("💳 پرداخت بدهی فروشنده"){showSupplierPayment()}
        btn("👤 برداشت شریک ۱"){showWithdrawal("شریک ۱")}; btn("👤 برداشت شریک ۲"){showWithdrawal("شریک ۲")}; btn("🔄 انتقال بین حساب‌ها"){showTransfer()}; btn("🏦 موجودی حساب‌ها"){showBalances()}; btn("📜 تاریخچه این شعبه"){showHistory(branch)}; btn("⬅ برگشت"){showHome()}
    }
    private fun accounts()=if(branch=="حرم") arrayOf("صندوق نقدی حرم","بانک پاسارگاد حرم","بانک سامان حرم") else arrayOf("صندوق نقدی آرایشی","بانک پاسارگاد آرایشی","بانک ملی آرایشی")
    private fun spinner(items:Array<String>):Spinner=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items);root.addView(this)}

    private fun showSales(){
        base("فروش روزانه — $branch"); val a=accounts(); val es=a.map{moneyInput("$it — تومان")};es.forEach{root.addView(it)}
        btn("ثبت فروش"){val vals=es.map{it.text.toString().toLongOrNull()?:0};val total=vals.sum();if(total<=0){toast("مبلغ فروش را وارد کن");return@btn};for(i in vals.indices)if(vals[i]>0)db.add("SALE",branch,"فروش روزانه",a[i],null,vals[i],0);toast("فروش ${fmt(total)} تومان ثبت شد");showBranch()};btn("⬅ برگشت"){showBranch()}
    }
    private fun showExpense(){
        base("ثبت هزینه — $branch");val desc=field("شرح هزینه");root.addView(desc);val amount=moneyInput();root.addView(amount);val sp=spinner(accounts())
        btn("ثبت هزینه"){val m=amount.text.toString().toLongOrNull()?:0;if(m<=0||desc.text.isBlank()){toast("شرح و مبلغ را وارد کن");return@btn};db.add("EXPENSE",branch,desc.text.toString(),sp.selectedItem.toString(),null,0,m);toast("هزینه ثبت شد");showBranch()};btn("⬅ برگشت"){showBranch()}
    }
    private fun showPurchase(){
        base("خرید نسیه — $branch");val supplier=field("نام فروشنده / تأمین‌کننده");root.addView(supplier);val amount=moneyInput();root.addView(amount)
        btn("ثبت خرید نسیه"){val m=amount.text.toString().toLongOrNull()?:0;if(supplier.text.isBlank()||m<=0){toast("فروشنده و مبلغ را وارد کن");return@btn};db.add("PURCHASE_CREDIT",branch,"خرید نسیه",null,supplier.text.toString(),m,0);toast("بدهی ${fmt(m)} تومان ثبت شد؛ پولی از حساب کم نشد");showBranch()};btn("⬅ برگشت"){showBranch()}
    }
    private fun showSupplierPayment(){
        base("پرداخت بدهی فروشنده — $branch");val supplier=field("نام فروشنده");root.addView(supplier);val amount=moneyInput();root.addView(amount);val sp=spinner(accounts())
        btn("ثبت پرداخت بدهی"){val m=amount.text.toString().toLongOrNull()?:0;if(supplier.text.isBlank()||m<=0){toast("فروشنده و مبلغ را وارد کن");return@btn};val debt=db.supplierBalance(branch,supplier.text.toString());if(m>debt){toast("بدهی فعلی ${fmt(debt)} تومان است");return@btn};db.add("SUPPLIER_PAYMENT",branch,"پرداخت بدهی",sp.selectedItem.toString(),supplier.text.toString(),m,0);toast("پرداخت ثبت شد");showBranch()};btn("⬅ برگشت"){showBranch()}
    }
    private fun showWithdrawal(partner:String){
        base("برداشت $partner — $branch");val amount=moneyInput();root.addView(amount);val sp=spinner(accounts())
        btn("ثبت برداشت"){val m=amount.text.toString().toLongOrNull()?:0;if(m<=0){toast("مبلغ را وارد کن");return@btn};db.add("WITHDRAWAL",branch,"برداشت $partner",sp.selectedItem.toString(),partner,m,0);toast("برداشت ثبت شد");showBranch()};btn("⬅ برگشت"){showBranch()}
    }
    private fun showTransfer(){
        base("انتقال بین حساب‌ها — $branch");val a=accounts();val from=spinner(a);val to=spinner(a);val amount=moneyInput();root.addView(amount)
        btn("ثبت انتقال"){val m=amount.text.toString().toLongOrNull()?:0;if(m<=0||from.selectedItem.toString()==to.selectedItem.toString()){toast("مبدأ، مقصد و مبلغ را درست وارد کن");return@btn};if(db.balance(branch,from.selectedItem.toString())<m){toast("موجودی حساب مبدأ کافی نیست");return@btn};db.add("TRANSFER",branch,"انتقال",from.selectedItem.toString(),to.selectedItem.toString(),m,0);toast("انتقال ثبت شد");showBranch()};btn("⬅ برگشت"){showBranch()}
    }
    private fun showBalances(){
        base("موجودی حساب‌ها — $branch");accounts().forEach{acc->val t=TextView(this);t.text="$acc\n${fmt(db.balance(branch,acc))} تومان";t.textSize=18f;t.gravity=Gravity.RIGHT;t.setPadding(10,15,10,15);root.addView(t)}
        val sup=db.supplierBalances(branch);val h=TextView(this);h.text="\nبدهی فروشنده‌ها:\n"+if(sup.isEmpty())"موردی ثبت نشده" else sup.entries.joinToString("\n"){"${it.key}: ${fmt(it.value)} تومان"};h.gravity=Gravity.RIGHT;h.textSize=17f;root.addView(h);btn("⬅ برگشت"){showBranch()}
    }

    private fun showHistory(filter:String?=null){
        base(if(filter==null)"همه تراکنش‌ها" else "تاریخچه — $filter");val rows=db.rows(filter)
        if(rows.isEmpty()){root.addView(TextView(this).apply{text="هنوز تراکنشی ثبت نشده";gravity=Gravity.RIGHT})}
        rows.forEach{r->
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,14,8,14)}
            val t=TextView(this).apply{text="${r.jalaliDate}\n${r.branch} — ${r.typeLabel}\n${r.desc}\nمبلغ: ${fmt(r.displayAmount)} تومان";gravity=Gravity.RIGHT;textSize=16f}
            box.addView(t); box.setOnClickListener{showEditDialog(r,filter)}; root.addView(box)
        }
        btn("⬅ برگشت"){if(filter==null)showHome() else showBranch()}
    }
    private fun showEditDialog(r:Row,filter:String?){
        AlertDialog.Builder(this).setTitle("ویرایش تراکنش").setItems(arrayOf("ویرایش مبلغ/شرح","حذف تراکنش","لغو")){_,which->
            when(which){0->editDialog(r,filter);1->AlertDialog.Builder(this).setTitle("حذف شود؟").setMessage("این تراکنش برای همیشه حذف می‌شود.").setNegativeButton("لغو",null).setPositiveButton("حذف"){_,_->db.delete(r.id);toast("حذف شد");showHistory(filter)}.show()}
        }.show()
    }
    private fun editDialog(r:Row,filter:String?){
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,20)}
        val d=field("شرح");d.setText(r.desc);layout.addView(d);val a=moneyInput();a.setText(r.displayAmount.toString());layout.addView(a)
        AlertDialog.Builder(this).setTitle("ویرایش").setView(layout).setNegativeButton("لغو",null).setPositiveButton("ذخیره"){_,_->val m=a.text.toString().toLongOrNull();if(m==null||m<0){toast("مبلغ نامعتبر");return@setPositiveButton};db.update(r.id,d.text.toString(),m);toast("ویرایش شد");showHistory(filter)}.show()
    }
    private fun showReport(){
        base("گزارش کلی");arrayOf("آرایشی","حرم").forEach{b->val sales=db.sumType(b,"SALE");val exp=db.sumType(b,"EXPENSE");val w1=db.sumPartnerWithdraw(b,"شریک ۱");val w2=db.sumPartnerWithdraw(b,"شریک ۲");val t=TextView(this);t.text="$b\nفروش: ${fmt(sales)} تومان\nهزینه: ${fmt(exp)} تومان\nبرداشت شریک ۱: ${fmt(w1)} تومان\nبرداشت شریک ۲: ${fmt(w2)} تومان\nخالص قبل از برداشت: ${fmt(sales-exp)} تومان\n";t.gravity=Gravity.RIGHT;t.textSize=18f;t.setPadding(8,15,8,15);root.addView(t)};btn("⬅ برگشت"){showHome()}
    }

    data class Row(val id:Long,val date:String,val branch:String,val type:String,val desc:String,val amount:Long,val expense:Long){
        val displayAmount get()=if(amount>0)amount else expense
        val typeLabel get()=when(type){"SALE"->"فروش";"EXPENSE"->"هزینه";"PURCHASE_CREDIT"->"خرید نسیه";"SUPPLIER_PAYMENT"->"پرداخت بدهی فروشنده";"WITHDRAWAL"->"برداشت";"TRANSFER"->"انتقال";else->type}
        val jalaliDate get()=Jalali.toJalali(date)
    }

    class LedgerDb(c:Context):SQLiteOpenHelper(c,"ledger.db",null,2){
        override fun onCreate(db:SQLiteDatabase){db.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,branch TEXT,type TEXT,desc TEXT,account TEXT,party TEXT,amount INTEGER,expense INTEGER)")}
        override fun onUpgrade(db:SQLiteDatabase,o:Int,n:Int){if(o<2){/* schema unchanged; v2 fixes semantics in code */}}
        fun add(type:String,branch:String,desc:String,account:String?,party:String?,amount:Long,expense:Long){val v=ContentValues();v.put("date",SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(Date()));v.put("branch",branch);v.put("type",type);v.put("desc",desc);v.put("account",account);v.put("party",party);v.put("amount",amount);v.put("expense",expense);writableDatabase.insert("tx",null,v)}
        fun update(id:Long,desc:String,amount:Long){val v=ContentValues();v.put("desc",desc);val c=readableDatabase.rawQuery("SELECT type FROM tx WHERE id=?",arrayOf(id.toString()));var type="";if(c.moveToFirst())type=c.getString(0);c.close();if(type=="EXPENSE")v.put("expense",amount) else v.put("amount",amount);writableDatabase.update("tx",v,"id=?",arrayOf(id.toString()))}
        fun delete(id:Long){writableDatabase.delete("tx","id=?",arrayOf(id.toString()))}
        fun rows(filter:String?):List<Row>{val q=if(filter==null)"SELECT id,date,branch,type,desc,amount,expense FROM tx ORDER BY id DESC" else "SELECT id,date,branch,type,desc,amount,expense FROM tx WHERE branch=? ORDER BY id DESC";val c=if(filter==null)readableDatabase.rawQuery(q,null) else readableDatabase.rawQuery(q,arrayOf(filter));val out=mutableListOf<Row>();while(c.moveToNext())out.add(Row(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getLong(5),c.getLong(6)));c.close();return out}
        fun balance(branch:String,account:String):Long{var x=0L;val c=readableDatabase.rawQuery("SELECT type,account,party,amount,expense FROM tx WHERE branch=?",arrayOf(branch));while(c.moveToNext()){when(c.getString(0)){"SALE"->if(c.getString(1)==account)x+=c.getLong(3);"EXPENSE"->if(c.getString(1)==account)x-=c.getLong(4);"WITHDRAWAL","SUPPLIER_PAYMENT"->if(c.getString(1)==account)x-=c.getLong(3);"TRANSFER"->{if(c.getString(1)==account)x-=c.getLong(3);if(c.getString(2)==account)x+=c.getLong(3)}}};c.close();return x}
        fun supplierBalance(branch:String,supplier:String):Long{var x=0L;val c=readableDatabase.rawQuery("SELECT type,party,amount FROM tx WHERE branch=? AND party=?",arrayOf(branch,supplier));while(c.moveToNext()){if(c.getString(0)=="PURCHASE_CREDIT")x+=c.getLong(2);if(c.getString(0)=="SUPPLIER_PAYMENT")x-=c.getLong(2)};c.close();return x}
        fun supplierBalances(branch:String):Map<String,Long>{val m=mutableMapOf<String,Long>();val c=readableDatabase.rawQuery("SELECT type,party,amount FROM tx WHERE branch=?",arrayOf(branch));while(c.moveToNext()){val p=c.getString(1)?:continue;val a=c.getLong(2);when(c.getString(0)){"PURCHASE_CREDIT"->m[p]=(m[p]?:0)+a;"SUPPLIER_PAYMENT"->m[p]=(m[p]?:0)-a}};c.close();return m.filterValues{it!=0L}}
        fun sumType(branch:String,type:String):Long{val c=readableDatabase.rawQuery("SELECT COALESCE(SUM(CASE WHEN type='EXPENSE' THEN expense ELSE amount END),0) FROM tx WHERE branch=? AND type=?",arrayOf(branch,type));c.moveToFirst();val x=c.getLong(0);c.close();return x}
        fun sumPartnerWithdraw(branch:String,partner:String):Long{val c=readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM tx WHERE branch=? AND type='WITHDRAWAL' AND party=?",arrayOf(branch,partner));c.moveToFirst();val x=c.getLong(0);c.close();return x}
    }

    object Jalali {
        fun toJalali(g:String):String { return try { val p=g.substring(0,10).split("-").map{it.toInt()}; val j=convert(p[0],p[1],p[2]); String.format("%04d/%02d/%02d %s",j[0],j[1],j[2],g.substring(11)) } catch(_:Exception){g} }
        private fun convert(gy:Int,gm:Int,gd:Int):IntArray{var jy=if(gy<=1600)0 else 979;var y=if(gy<=1600)gy-621 else gy-1600;val gy2=if(gm>2)y+1 else y;var days=365*y+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400;days+=gd+if(gm<7)(gm-1)*31 else (gm-1)*30+6;val base=days-79;jy+=33*(base/12053);var r=base%12053;jy+=4*(r/1461);r%=1461;if(r>365){jy+=(r-1)/365;r=(r-1)%365};val jm=if(r<186)1+r/31 else 7+(r-186)/30;val jd=1+if(r<186)r%31 else (r-186)%30;return intArrayOf(jy,jm,jd)}
    }
}
