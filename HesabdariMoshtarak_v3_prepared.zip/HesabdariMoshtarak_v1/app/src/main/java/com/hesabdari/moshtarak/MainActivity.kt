package com.hesabdari.moshtarak

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.sqlite.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var db: LedgerDb
    private lateinit var root: LinearLayout
    private var branch = "حرم"

    private val blue = Color.rgb(25, 87, 160)
    private val navy = Color.rgb(20, 34, 61)
    private val purple = Color.rgb(106, 76, 147)
    private val red = Color.rgb(190, 55, 65)
    private val green = Color.rgb(35, 135, 88)
    private val bg = Color.rgb(246, 248, 252)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        db = LedgerDb(this)
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun base(title: String, subtitle: String? = null) {
        root = findViewById(R.id.root)
        root.removeAllViews()
        root.setBackgroundColor(bg)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(12))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val t = TextView(this).apply {
            text = title; textSize = 25f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(navy); gravity = Gravity.RIGHT
        }
        head.addView(t)
        subtitle?.let {
            head.addView(TextView(this).apply { text = it; textSize = 14f; setTextColor(Color.DKGRAY); gravity = Gravity.RIGHT; setPadding(0, dp(5), 0, 0) })
        }
        root.addView(head)
    }

    private fun cardButton(text: String, color: Int = blue, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text; textSize = 16f; isAllCaps = false; setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER
            background = rounded(color, 16)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, dp(54)).also { it.setMargins(0, dp(6), 0, dp(6)) })
    }

    private fun addLabel(text: String) {
        root.addView(TextView(this).apply { this.text = text; textSize = 14f; setTextColor(Color.DKGRAY); gravity = Gravity.RIGHT; setPadding(dp(4), dp(7), dp(4), dp(3)) })
    }

    private fun field(hint: String): EditText = EditText(this).apply {
        this.hint = hint; textSize = 16f; gravity = Gravity.RIGHT; inputType = InputType.TYPE_CLASS_TEXT
        background = rounded(Color.WHITE, 12); setPadding(dp(12), dp(6), dp(12), dp(6))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun moneyInput(hint: String = "مبلغ به تومان"): EditText = EditText(this).apply {
        this.hint = hint; inputType = InputType.TYPE_CLASS_NUMBER; textSize = 17f; gravity = Gravity.RIGHT
        background = rounded(Color.WHITE, 12); setPadding(dp(12), dp(6), dp(12), dp(6))
    }

    private fun addView(v: View) { root.addView(v, LinearLayout.LayoutParams(-1, dp(58)).also { it.setMargins(0, dp(3), 0, dp(3)) }) }
    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun fmt(n: Long) = String.format("%,d", n)
    private fun todayJalali() = Jalali.toJalali(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))

    private fun showHome() {
        base("حسابداری مشترک", "مدیریت فروش، هزینه، فاکتور خرید و حساب فروشنده‌ها")
        addLabel("انتخاب شعبه")
        cardButton("🏪  آرایشی", blue) { branch = "آرایشی"; showBranch() }
        cardButton("🕌  حرم", purple) { branch = "حرم"; showBranch() }
        cardButton("📊  گزارش کلی", navy) { showReport() }
        cardButton("📜  همه تراکنش‌ها", Color.DKGRAY) { showHistory() }
    }

    private fun showBranch() {
        base(branch, "صندوق‌ها و بانک‌های شعبه $branch")
        cardButton("💰  ثبت فروش روزانه", blue) { showSales() }
        cardButton("💸  هزینه‌ها", red) { showExpenses() }
        cardButton("🧾  فاکتور خرید", purple) { showPurchase() }
        cardButton("🏢  فروشنده‌ها / شرکت‌ها", navy) { showSuppliers() }
        cardButton("💳  پرداخت بدهی فروشنده", green) { showSupplierPayment() }
        cardButton("👤  برداشت محمدرضا", Color.rgb(72, 92, 125)) { showWithdrawal("محمدرضا") }
        cardButton("👤  برداشت علیرضا", Color.rgb(72, 92, 125)) { showWithdrawal("علیرضا") }
        cardButton("🔄  انتقال بین حساب‌ها", blue) { showTransfer() }
        cardButton("🏦  موجودی حساب‌ها", green) { showBalances() }
        cardButton("📜  تاریخچه شعبه", Color.DKGRAY) { showHistory(branch) }
        cardButton("⬅  برگشت", Color.GRAY) { showHome() }
    }

    private fun accounts() = if (branch == "حرم") arrayOf("صندوق نقدی حرم", "بانک پاسارگاد حرم", "بانک سامان حرم") else arrayOf("صندوق نقدی آرایشی", "بانک پاسارگاد آرایشی", "بانک ملی آرایشی")
    private fun spinner(items: Array<String>): Spinner = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        background = rounded(Color.WHITE, 12); layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.addView(this, LinearLayout.LayoutParams(-1, dp(58)).also { it.setMargins(0, dp(3), 0, dp(3)) })
    }

    private fun showSales() {
        base("فروش روزانه — $branch", "مبلغ فروش را برای هر حساب دریافت‌کننده وارد کن")
        val a = accounts(); val es = a.map { moneyInput(it) }; es.forEach { addView(it) }
        cardButton("ثبت فروش", green) {
            val vals = es.map { it.text.toString().toLongOrNull() ?: 0L }; val total = vals.sum()
            if (total <= 0) { toast("حداقل یک مبلغ فروش وارد کن"); return@cardButton }
            for (i in vals.indices) if (vals[i] > 0) db.add("SALE", branch, "فروش روزانه", a[i], null, vals[i], 0)
            toast("فروش ${fmt(total)} تومان ثبت شد"); showBranch()
        }
        cardButton("⬅ برگشت", Color.GRAY) { showBranch() }
    }

    private fun showExpenses() {
        base("هزینه‌ها — $branch", "ثبت و مشاهده جداگانه هزینه‌ها")
        cardButton("➕  ثبت هزینه جدید", red) { showExpense() }
        cardButton("📋  مشاهده هزینه‌های ثبت‌شده", navy) { showExpenseHistory() }
        cardButton("⚙  مدیریت دسته‌های هزینه", Color.DKGRAY) { manageExpenseCategories() }
        cardButton("⬅ برگشت", Color.GRAY) { showBranch() }
    }

    private fun showExpense() {
        base("ثبت هزینه — $branch", "تاریخ: ${todayJalali()}")
        addLabel("دسته هزینه")
        val categories = db.expenseCategories(branch).toTypedArray()
        val cat = spinner(categories)
        addLabel("شرح / توضیحات")
        val desc = field("مثلاً اجاره مهر ماه"); addView(desc)
        addLabel("حساب پرداخت‌کننده")
        val sp = spinner(accounts())
        addLabel("مبلغ")
        val amount = moneyInput(); addView(amount)
        cardButton("ثبت هزینه", red) {
            val m = amount.text.toString().toLongOrNull() ?: 0L
            if (m <= 0) { toast("مبلغ را وارد کن"); return@cardButton }
            val text = if (desc.text.isBlank()) cat.selectedItem.toString() else "${cat.selectedItem}: ${desc.text}"
            db.add("EXPENSE", branch, text, sp.selectedItem.toString(), null, 0, m)
            toast("هزینه ثبت شد"); showExpenses()
        }
        cardButton("⬅ برگشت", Color.GRAY) { showExpenses() }
    }

    private fun showExpenseHistory() {
        base("هزینه‌های $branch")
        val rows = db.rows(branch).filter { it.type == "EXPENSE" }
        if (rows.isEmpty()) addLabel("هنوز هزینه‌ای ثبت نشده")
        rows.forEach { r -> addHistoryCard(r, branch) }
        cardButton("⬅ برگشت", Color.GRAY) { showExpenses() }
    }

    private fun manageExpenseCategories() {
        base("دسته‌های هزینه — $branch")
        db.expenseCategories(branch).forEach { addLabel("• $it") }
        val input = field("دسته جدید"); addView(input)
        cardButton("➕ افزودن دسته", purple) {
            if (input.text.isBlank()) { toast("نام دسته را وارد کن"); return@cardButton }
            db.addExpenseCategory(branch, input.text.toString().trim()); toast("دسته اضافه شد"); manageExpenseCategories()
        }
        cardButton("⬅ برگشت", Color.GRAY) { showExpenses() }
    }

    private fun showPurchase() {
        base("فاکتور خرید — $branch", "تاریخ: ${todayJalali()}")
        addLabel("نام فروشنده")
        val suppliers = db.suppliers(branch).toTypedArray()
        val supplier = if (suppliers.isNotEmpty()) spinner(suppliers) else null
        val newSupplier = field(if (supplier == null) "نام فروشنده / شرکت" else "اگر فروشنده جدید است، اینجا وارد کن")
        addView(newSupplier)
        addLabel("مبلغ فاکتور")
        val amount = moneyInput(); addView(amount)
        val cash = CheckBox(this).apply { text = "نقدی پرداخت میکنم"; textSize = 16f; isChecked = false; gravity = Gravity.RIGHT }
        root.addView(cash, LinearLayout.LayoutParams(-1, dp(52)))
        addLabel("حساب پرداخت‌کننده (فقط در خرید نقدی)")
        val account = spinner(accounts())
        account.isEnabled = false; cash.setOnCheckedChangeListener { _, checked -> account.isEnabled = checked }
        cardButton("ثبت فاکتور خرید", purple) {
            val m = amount.text.toString().toLongOrNull() ?: 0L
            val chosen = newSupplier.text.toString().trim().ifBlank { supplier?.selectedItem?.toString() ?: "" }
            if (chosen.isBlank() || m <= 0) { toast("فروشنده و مبلغ را کامل وارد کن"); return@cardButton }
            db.ensureSupplier(branch, chosen)
            if (cash.isChecked) {
                if (db.balance(branch, account.selectedItem.toString()) < m) { toast("موجودی حساب کافی نیست"); return@cardButton }
                db.add("PURCHASE_CASH", branch, "فاکتور خرید نقدی", account.selectedItem.toString(), chosen, m, 0)
                toast("فاکتور نقدی ثبت شد")
            } else {
                db.add("PURCHASE_CREDIT", branch, "فاکتور خرید", null, chosen, m, 0)
                toast("فاکتور ثبت شد؛ ${fmt(m)} تومان به بدهی فروشنده اضافه شد")
            }
            showBranch()
        }
        cardButton("⬅ برگشت", Color.GRAY) { showBranch() }
    }

    private fun showSuppliers() {
        base("فروشنده‌ها و شرکت‌ها — $branch", "هر فروشنده حساب و گردش مستقل دارد")
        val list = db.suppliers(branch)
        if (list.isEmpty()) addLabel("هنوز فروشنده‌ای ثبت نشده")
        list.forEach { s ->
            val bal = db.supplierBalance(branch, s)
            val text = "$s\nبدهی فعلی: ${fmt(bal)} تومان\nخرید: ${fmt(db.supplierPurchases(branch, s))} | پرداخت: ${fmt(db.supplierPayments(branch, s))}"
            val tv = TextView(this).apply { this.text = text; textSize = 16f; gravity = Gravity.RIGHT; setTextColor(navy); background = rounded(Color.WHITE, 14); setPadding(dp(14), dp(12), dp(14), dp(12)); setOnClickListener { showSupplierDetail(s) } }
            root.addView(tv, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.setMargins(0, dp(6), 0, dp(6)) })
        }
        cardButton("➕ افزودن فروشنده", blue) {
            val e = field("نام شخص / شرکت")
            AlertDialog.Builder(this).setTitle("فروشنده جدید").setView(e).setNegativeButton("لغو", null).setPositiveButton("ذخیره") { _, _ -> if (e.text.isNotBlank()) { db.ensureSupplier(branch, e.text.toString().trim()); showSuppliers() } }.show()
        }
        cardButton("⬅ برگشت", Color.GRAY) { showBranch() }
    }

    private fun showSupplierDetail(supplier: String) {
        base(supplier, "دفتر حساب فروشنده — $branch")
        val bal = db.supplierBalance(branch, supplier)
        addLabel("بدهی فعلی: ${fmt(bal)} تومان")
        addLabel("مجموع خرید: ${fmt(db.supplierPurchases(branch, supplier))} تومان")
        addLabel("مجموع پرداخت: ${fmt(db.supplierPayments(branch, supplier))} تومان")
        db.rows(branch).filter { it.party == supplier && (it.type == "PURCHASE_CREDIT" || it.type == "PURCHASE_CASH" || it.type == "SUPPLIER_PAYMENT") }.forEach { addHistoryCard(it, branch) }
        cardButton("⬅ برگشت", Color.GRAY) { showSuppliers() }
    }

    private fun showSupplierPayment() {
        base("پرداخت بدهی فروشنده — $branch")
        val suppliers = db.suppliers(branch).toTypedArray()
        if (suppliers.isEmpty()) { addLabel("ابتدا یک فاکتور خرید برای فروشنده ثبت کن"); cardButton("⬅ برگشت", Color.GRAY) { showBranch() }; return }
        addLabel("فروشنده")
        val supplier = spinner(suppliers)
        addLabel("حساب پرداخت‌کننده")
        val account = spinner(accounts())
        addLabel("مبلغ پرداخت")
        val amount = moneyInput(); addView(amount)
        cardButton("ثبت پرداخت", green) {
            val m = amount.text.toString().toLongOrNull() ?: 0L
            val s = supplier.selectedItem.toString(); val debt = db.supplierBalance(branch, s)
            if (m <= 0) { toast("مبلغ را وارد کن"); return@cardButton }
            if (m > debt) { toast("بدهی فعلی ${fmt(debt)} تومان است"); return@cardButton }
            if (db.balance(branch, account.selectedItem.toString()) < m) { toast("موجودی حساب کافی نیست"); return@cardButton }
            db.add("SUPPLIER_PAYMENT", branch, "پرداخت بدهی", account.selectedItem.toString(), s, m, 0)
            toast("پرداخت ثبت شد"); showBranch()
        }
        cardButton("⬅ برگشت", Color.GRAY) { showBranch() }
    }

    private fun showWithdrawal(partner: String) {
        base("برداشت $partner — $branch")
        addLabel("حساب برداشت")
        val sp = spinner(accounts()); addLabel("مبلغ"); val amount = moneyInput(); addView(amount)
        cardButton("ثبت برداشت", red) {
            val m = amount.text.toString().toLongOrNull() ?: 0L
            if (m <= 0) { toast("مبلغ را وارد کن"); return@cardButton }
            if (db.balance(branch, sp.selectedItem.toString()) < m) { toast("موجودی حساب کافی نیست"); return@cardButton }
            db.add("WITHDRAWAL", branch, "برداشت $partner", sp.selectedItem.toString(), partner, m, 0); toast("برداشت ثبت شد"); showBranch()
        }
        cardButton("⬅ برگشت", Color.GRAY) { showBranch() }
    }

    private fun showTransfer() {
        base("انتقال بین حساب‌ها — $branch")
        val a = accounts(); addLabel("از حساب"); val from = spinner(a); addLabel("به حساب"); val to = spinner(a); addLabel("مبلغ"); val amount = moneyInput(); addView(amount)
        cardButton("ثبت انتقال", blue) {
            val m = amount.text.toString().toLongOrNull() ?: 0L
            if (m <= 0 || from.selectedItem.toString() == to.selectedItem.toString()) { toast("مبدأ، مقصد و مبلغ را درست وارد کن"); return@cardButton }
            if (db.balance(branch, from.selectedItem.toString()) < m) { toast("موجودی حساب مبدأ کافی نیست"); return@cardButton }
            db.add("TRANSFER", branch, "انتقال", from.selectedItem.toString(), to.selectedItem.toString(), m, 0); toast("انتقال ثبت شد"); showBranch()
        }
        cardButton("⬅ برگشت", Color.GRAY) { showBranch() }
    }

    private fun showBalances() {
        base("موجودی حساب‌ها — $branch")
        accounts().forEach { acc ->
            val t = TextView(this).apply { text = "$acc\n${fmt(db.balance(branch, acc))} تومان"; textSize = 18f; gravity = Gravity.RIGHT; setTextColor(navy); background = rounded(Color.WHITE, 14); setPadding(dp(14), dp(12), dp(14), dp(12)) }
            root.addView(t, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.setMargins(0, dp(6), 0, dp(6)) })
        }
        addLabel("بدهی فروشنده‌ها")
        db.supplierBalances(branch).forEach { (name, value) -> addLabel("$name: ${fmt(value)} تومان") }
        cardButton("⬅ برگشت", Color.GRAY) { showBranch() }
    }

    private fun addHistoryCard(r: Row, filter: String?) {
        val box = TextView(this).apply {
            text = "${r.jalaliDate}\n${r.typeLabel}\n${r.desc}\n${r.accountLabel}\n${r.partyLabel}\nمبلغ: ${fmt(r.displayAmount)} تومان"
            gravity = Gravity.RIGHT; textSize = 15f; setTextColor(navy); background = rounded(Color.WHITE, 14); setPadding(dp(14), dp(12), dp(14), dp(12)); setOnClickListener { showEditDialog(r, filter) }
        }
        root.addView(box, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.setMargins(0, dp(6), 0, dp(6)) })
    }

    private fun showHistory(filter: String? = null) {
        base(if (filter == null) "همه تراکنش‌ها" else "تاریخچه — $filter")
        val rows = db.rows(filter)
        if (rows.isEmpty()) addLabel("هنوز تراکنشی ثبت نشده") else rows.forEach { addHistoryCard(it, filter) }
        cardButton("⬅ برگشت", Color.GRAY) { if (filter == null) showHome() else showBranch() }
    }

    private fun showEditDialog(r: Row, filter: String?) {
        AlertDialog.Builder(this).setTitle("ویرایش تراکنش").setItems(arrayOf("ویرایش مبلغ/شرح", "حذف تراکنش", "لغو")) { _, which ->
            when (which) {
                0 -> editDialog(r, filter)
                1 -> AlertDialog.Builder(this).setTitle("حذف شود؟").setMessage("این تراکنش برای همیشه حذف می‌شود.").setNegativeButton("لغو", null).setPositiveButton("حذف") { _, _ -> db.delete(r.id); toast("حذف شد"); showHistory(filter) }.show()
            }
        }.show()
    }

    private fun editDialog(r: Row, filter: String?) {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)) }
        val d = field("شرح"); d.setText(r.desc); layout.addView(d)
        val a = moneyInput(); a.setText(r.displayAmount.toString()); layout.addView(a)
        AlertDialog.Builder(this).setTitle("ویرایش").setView(layout).setNegativeButton("لغو", null).setPositiveButton("ذخیره") { _, _ ->
            val m = a.text.toString().toLongOrNull()
            if (m == null || m < 0) { toast("مبلغ نامعتبر") } else { db.update(r.id, d.text.toString(), m); toast("ویرایش شد"); showHistory(filter) }
        }.show()
    }

    private fun showReport() {
        base("گزارش کلی", "خلاصه دو شعبه")
        arrayOf("آرایشی", "حرم").forEach { b ->
            val sales = db.sumType(b, "SALE"); val exp = db.sumType(b, "EXPENSE"); val w1 = db.sumPartnerWithdraw(b, "محمدرضا"); val w2 = db.sumPartnerWithdraw(b, "علیرضا"); val debts = db.supplierBalances(b).values.sum()
            val t = TextView(this).apply { text = "$b\nفروش: ${fmt(sales)} تومان\nهزینه: ${fmt(exp)} تومان\nبرداشت محمدرضا: ${fmt(w1)} تومان\nبرداشت علیرضا: ${fmt(w2)} تومان\nبدهی فروشنده‌ها: ${fmt(debts)} تومان\nخالص قبل از برداشت: ${fmt(sales - exp)} تومان"; gravity = Gravity.RIGHT; textSize = 17f; setTextColor(navy); background = rounded(Color.WHITE, 16); setPadding(dp(14), dp(14), dp(14), dp(14)) }
            root.addView(t, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.setMargins(0, dp(8), 0, dp(8)) })
        }
        cardButton("⬅ برگشت", Color.GRAY) { showHome() }
    }

    data class Row(val id: Long, val date: String, val branch: String, val type: String, val desc: String, val account: String?, val party: String?, val amount: Long, val expense: Long) {
        val displayAmount get() = if (amount > 0) amount else expense
        val typeLabel get() = when (type) { "SALE" -> "فروش"; "EXPENSE" -> "هزینه"; "PURCHASE_CREDIT" -> "فاکتور خرید"; "PURCHASE_CASH" -> "فاکتور خرید نقدی"; "SUPPLIER_PAYMENT" -> "پرداخت بدهی فروشنده"; "WITHDRAWAL" -> "برداشت"; "TRANSFER" -> "انتقال"; else -> type }
        val accountLabel get() = if (account.isNullOrBlank()) "" else "حساب: $account"
        val partyLabel get() = if (party.isNullOrBlank()) "" else "طرف حساب: $party"
        val jalaliDate get() = Jalali.toJalali(date)
    }

    class LedgerDb(c: Context) : SQLiteOpenHelper(c, "ledger.db", null, 3) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,branch TEXT,type TEXT,desc TEXT,account TEXT,party TEXT,amount INTEGER,expense INTEGER)")
            db.execSQL("CREATE TABLE suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,branch TEXT,name TEXT,UNIQUE(branch,name))")
            db.execSQL("CREATE TABLE expense_categories(id INTEGER PRIMARY KEY AUTOINCREMENT,branch TEXT,name TEXT,UNIQUE(branch,name))")
            seed(db)
        }
        override fun onUpgrade(db: SQLiteDatabase, old: Int, newV: Int) {
            if (old < 3) {
                db.execSQL("CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,branch TEXT,name TEXT,UNIQUE(branch,name))")
                db.execSQL("CREATE TABLE IF NOT EXISTS expense_categories(id INTEGER PRIMARY KEY AUTOINCREMENT,branch TEXT,name TEXT,UNIQUE(branch,name))")
                seed(db)
            }
        }
        private fun seed(db: SQLiteDatabase) {
            val cats = arrayOf("اجاره", "خرید پلاستیک", "پول برق", "آب", "اینترنت", "حمل‌ونقل", "متفرقه")
            arrayOf("آرایشی", "حرم").forEach { b -> cats.forEach { insertCategory(db, b, it) } }
        }
        private fun insertCategory(db: SQLiteDatabase, branch: String, name: String) { val v = ContentValues(); v.put("branch", branch); v.put("name", name); db.insertWithOnConflict("expense_categories", null, v, SQLiteDatabase.CONFLICT_IGNORE) }
        fun add(type: String, branch: String, desc: String, account: String?, party: String?, amount: Long, expense: Long) {
            val v = ContentValues(); v.put("date", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())); v.put("branch", branch); v.put("type", type); v.put("desc", desc); v.put("account", account); v.put("party", party); v.put("amount", amount); v.put("expense", expense); writableDatabase.insert("tx", null, v)
        }
        fun update(id: Long, desc: String, amount: Long) { val v = ContentValues(); v.put("desc", desc); val c = readableDatabase.rawQuery("SELECT type FROM tx WHERE id=?", arrayOf(id.toString())); var type = ""; if (c.moveToFirst()) type = c.getString(0); c.close(); if (type == "EXPENSE") v.put("expense", amount) else v.put("amount", amount); writableDatabase.update("tx", v, "id=?", arrayOf(id.toString())) }
        fun delete(id: Long) { writableDatabase.delete("tx", "id=?", arrayOf(id.toString())) }
        fun rows(filter: String?): List<Row> {
            val q = if (filter == null) "SELECT id,date,branch,type,desc,account,party,amount,expense FROM tx ORDER BY id DESC" else "SELECT id,date,branch,type,desc,account,party,amount,expense FROM tx WHERE branch=? ORDER BY id DESC"
            val c = if (filter == null) readableDatabase.rawQuery(q, null) else readableDatabase.rawQuery(q, arrayOf(filter)); val out = mutableListOf<Row>()
            while (c.moveToNext()) out.add(Row(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5), c.getString(6), c.getLong(7), c.getLong(8))); c.close(); return out
        }
        fun balance(branch: String, account: String): Long {
            var x = 0L; val c = readableDatabase.rawQuery("SELECT type,account,party,amount,expense FROM tx WHERE branch=?", arrayOf(branch))
            while (c.moveToNext()) when (c.getString(0)) {
                "SALE" -> if (c.getString(1) == account) x += c.getLong(3)
                "EXPENSE", "WITHDRAWAL", "SUPPLIER_PAYMENT", "PURCHASE_CASH" -> if (c.getString(1) == account) x -= if (c.getString(0) == "EXPENSE") c.getLong(4) else c.getLong(3)
                "TRANSFER" -> { if (c.getString(1) == account) x -= c.getLong(3); if (c.getString(2) == account) x += c.getLong(3) }
            }
            c.close(); return x
        }
        fun ensureSupplier(branch: String, name: String) { val v = ContentValues(); v.put("branch", branch); v.put("name", name); writableDatabase.insertWithOnConflict("suppliers", null, v, SQLiteDatabase.CONFLICT_IGNORE) }
        fun suppliers(branch: String): List<String> { val c = readableDatabase.rawQuery("SELECT name FROM suppliers WHERE branch=? ORDER BY name", arrayOf(branch)); val out = mutableListOf<String>(); while (c.moveToNext()) out.add(c.getString(0)); c.close(); return out }
        fun supplierBalance(branch: String, supplier: String): Long { var x = 0L; val c = readableDatabase.rawQuery("SELECT type,amount FROM tx WHERE branch=? AND party=?", arrayOf(branch, supplier)); while (c.moveToNext()) { if (c.getString(0) == "PURCHASE_CREDIT") x += c.getLong(1); if (c.getString(0) == "SUPPLIER_PAYMENT") x -= c.getLong(1) }; c.close(); return x }
        fun supplierPurchases(branch: String, supplier: String): Long { val c = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM tx WHERE branch=? AND party=? AND type IN ('PURCHASE_CREDIT','PURCHASE_CASH')", arrayOf(branch, supplier)); c.moveToFirst(); val x = c.getLong(0); c.close(); return x }
        fun supplierPayments(branch: String, supplier: String): Long { val c = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM tx WHERE branch=? AND party=? AND type='SUPPLIER_PAYMENT'", arrayOf(branch, supplier)); c.moveToFirst(); val x = c.getLong(0); c.close(); return x }
        fun supplierBalances(branch: String): Map<String, Long> { val m = mutableMapOf<String, Long>(); val c = readableDatabase.rawQuery("SELECT party,type,amount FROM tx WHERE branch=? AND party IS NOT NULL", arrayOf(branch)); while (c.moveToNext()) { val p = c.getString(0); val a = c.getLong(2); when (c.getString(1)) { "PURCHASE_CREDIT" -> m[p] = (m[p] ?: 0) + a; "SUPPLIER_PAYMENT" -> m[p] = (m[p] ?: 0) - a } }; c.close(); return m.filterValues { it != 0L } }
        fun expenseCategories(branch: String): List<String> { val c = readableDatabase.rawQuery("SELECT name FROM expense_categories WHERE branch=? ORDER BY id", arrayOf(branch)); val out = mutableListOf<String>(); while (c.moveToNext()) out.add(c.getString(0)); c.close(); return out }
        fun addExpenseCategory(branch: String, name: String) { val v = ContentValues(); v.put("branch", branch); v.put("name", name); writableDatabase.insertWithOnConflict("expense_categories", null, v, SQLiteDatabase.CONFLICT_IGNORE) }
        fun sumType(branch: String, type: String): Long { val c = readableDatabase.rawQuery("SELECT COALESCE(SUM(CASE WHEN type='EXPENSE' THEN expense ELSE amount END),0) FROM tx WHERE branch=? AND type=?", arrayOf(branch, type)); c.moveToFirst(); val x = c.getLong(0); c.close(); return x }
        fun sumPartnerWithdraw(branch: String, partner: String): Long { val c = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM tx WHERE branch=? AND type='WITHDRAWAL' AND party=?", arrayOf(branch, partner)); c.moveToFirst(); val x = c.getLong(0); c.close(); return x }
    }

    object Jalali {
        fun toJalali(g: String): String = try { val p = g.substring(0, 10).split("-").map { it.toInt() }; val j = convert(p[0], p[1], p[2]); String.format("%04d/%02d/%02d %s", j[0], j[1], j[2], g.substring(11)) } catch (_: Exception) { g }
        private fun convert(gy: Int, gm: Int, gd: Int): IntArray { var jy = if (gy <= 1600) 0 else 979; val y = if (gy <= 1600) gy - 621 else gy - 1600; val gy2 = if (gm > 2) y + 1 else y; var days = 365 * y + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400; days += gd + if (gm < 7) (gm - 1) * 31 else (gm - 1) * 30 + 6; val base = days - 79; jy += 33 * (base / 12053); var r = base % 12053; jy += 4 * (r / 1461); r %= 1461; if (r > 365) { jy += (r - 1) / 365; r = (r - 1) % 365 }; val jm = if (r < 186) 1 + r / 31 else 7 + (r - 186) / 30; val jd = 1 + if (r < 186) r % 31 else (r - 186) % 30; return intArrayOf(jy, jm, jd) }
    }
}
