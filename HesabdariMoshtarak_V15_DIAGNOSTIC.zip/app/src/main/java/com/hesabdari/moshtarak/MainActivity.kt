package com.hesabdari.moshtarak

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import com.google.firebase.Timestamp
import java.security.MessageDigest
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var db: LedgerDb
    private lateinit var root: LinearLayout
    private lateinit var auth: FirebaseAuth
    private lateinit var cloud: FirebaseFirestore
    private var txListener: ListenerRegistration? = null
    private var supplierListener: ListenerRegistration? = null
    private var categoryListener: ListenerRegistration? = null
    private var branch = "حرم"
    private var fullSyncStarted = false
    private var legacyMigrationRunning = false
    private var syncBootstrapRunning = false
    private val syncHandler = Handler(Looper.getMainLooper())
    private var syncRetryScheduled = false
    private var syncOk = false
    private var syncError: String? = null
    private var lastSyncAt: Long = 0L
    private var currentRenderer: (() -> Unit)? = null
    private var refreshScheduled = false

    private val blue = Color.rgb(32, 96, 180)
    private val blueDark = Color.rgb(20, 48, 92)
    private val purple = Color.rgb(112, 76, 164)
    private val red = Color.rgb(195, 58, 67)
    private val green = Color.rgb(35, 142, 91)
    private val orange = Color.rgb(215, 126, 47)
    private val bg = Color.rgb(244, 247, 252)
    private val text = Color.rgb(27, 39, 63)
    private val muted = Color.rgb(102, 115, 139)
    private val lightBlue = Color.rgb(232, 241, 255)
    private val lightPurple = Color.rgb(242, 235, 250)
    private val lightRed = Color.rgb(253, 237, 239)
    private val lightGreen = Color.rgb(232, 247, 239)
    private val workspaceId = "shared-shop"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // If the previous launch crashed, show the saved report before starting
        // Firebase or opening the local database again.
        val crashFile = File(filesDir, "last_crash.txt")
        if (crashFile.exists()) {
            val oldReport = runCatching { crashFile.readText() }
                .getOrElse { "گزارش خطای قبلی قابل خواندن نیست: ${it.message}" }
            showDiagnosticReport(oldReport)
            return
        }

        try {
            setContentView(R.layout.activity_main)
            db = LedgerDb(this)
            auth = FirebaseAuth.getInstance()
            cloud = FirebaseFirestore.getInstance()
            if (auth.currentUser == null) showLogin() else startCloudSync()
        } catch (t: Throwable) {
            val report = makeDiagnosticReport("خطا هنگام شروع برنامه", t)
            runCatching { crashFile.writeText(report) }
            showDiagnosticReport(report)
        }
    }

    private fun makeDiagnosticReport(title: String, error: Throwable): String = buildString {
        appendLine("حسابداری مشترک - گزارش تشخیصی V15")
        appendLine(title)
        appendLine("زمان: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())}")
        appendLine("Package: $packageName")
        appendLine("Android SDK: ${android.os.Build.VERSION.SDK_INT}")
        appendLine("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
        appendLine()
        append(android.util.Log.getStackTraceString(error))
    }

    private fun showDiagnosticReport(report: String) {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.WHITE)
        }
        val title = TextView(this).apply {
            text = "گزارش خطای برنامه"
            textSize = 20f
            setTextColor(Color.rgb(20, 48, 92))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }
        page.addView(title, LinearLayout.LayoutParams(-1, dp(48)))
        val hint = TextView(this).apply {
            text = "از این صفحه عکس بگیر و برای پشتیبانی بفرست؛ متن گزارش را هم می‌توانی کپی کنی."
            textSize = 14f
            setTextColor(Color.DKGRAY)
        }
        page.addView(hint, LinearLayout.LayoutParams(-1, dp(60)))
        val scroll = ScrollView(this)
        val details = TextView(this).apply {
            text = report
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.BLACK)
            setTextIsSelectable(true)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        scroll.addView(details)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val copyButton = Button(this).apply {
            text = "کپی گزارش خطا"
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Crash report", report))
                Toast.makeText(this@MainActivity, "گزارش کپی شد؛ آن را اینجا ارسال کن", Toast.LENGTH_LONG).show()
            }
        }
        page.addView(copyButton, LinearLayout.LayoutParams(-1, dp(52)))

        val retryButton = Button(this).apply {
            text = "پاک کردن گزارش و تلاش دوباره"
            setOnClickListener {
                runCatching { File(filesDir, "last_crash.txt").delete() }
                recreate()
            }
        }
        page.addView(retryButton, LinearLayout.LayoutParams(-1, dp(52)))
        setContentView(page)
    }

    override fun onResume() {
        super.onResume()
        if (::auth.isInitialized && auth.currentUser != null) {
            uploadPendingLocalData()
            requestScreenRefresh()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::auth.isInitialized && auth.currentUser != null) {
            requestScreenRefresh()
        }
    }

    override fun onDestroy() {
        txListener?.remove()
        supplierListener?.remove()
        categoryListener?.remove()
        syncHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, strokeColor: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (strokeColor != null) setStroke(dp(1), strokeColor)
        }

    private fun gradient(top: Int, bottom: Int, radius: Int): GradientDrawable =
        GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(top, bottom)
        ).apply { cornerRadius = dp(radius).toFloat() }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun fmt(value: Long): String = String.format(Locale.US, "%,d", value)

    private fun normalizeDigits(value: String): String = buildString {
        value.forEach { ch ->
            append(
                when (ch) {
                    in '۰'..'۹' -> ('0'.code + (ch.code - '۰'.code)).toChar()
                    in '٠'..'٩' -> ('0'.code + (ch.code - '٠'.code)).toChar()
                    else -> ch
                }
            )
        }
    }

    private fun moneyValue(field: EditText): Long = normalizeDigits(field.text.toString())
        .replace(",", "")
        .replace("٬", "")
        .filter(Char::isDigit)
        .toLongOrNull() ?: 0L

    private fun field(hint: String, numeric: Boolean = false): EditText = EditText(this).apply {
        this.hint = hint
        textSize = if (numeric) 17f else 16f
        gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
        background = rounded(Color.WHITE, 14, Color.rgb(222, 229, 241))
        setPadding(dp(14), dp(5), dp(14), dp(5))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun moneyInput(hint: String = "مبلغ به تومان"): EditText = field(hint, true).apply {
        addTextChangedListener(object : TextWatcher {
            private var internal = false
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(editable: Editable?) {
                if (internal) return
                val current = editable?.toString().orEmpty()
                val digits = normalizeDigits(current).replace(",", "").replace("٬", "").filter(Char::isDigit)
                if (digits.isEmpty()) return
                val formatted = digits.toLongOrNull()?.let { String.format(Locale.US, "%,d", it) } ?: return
                if (formatted != current) {
                    internal = true
                    setText(formatted)
                    setSelection(formatted.length)
                    internal = false
                }
            }
        })
    }

    private fun addView(view: View, height: Int = 58) {
        root.addView(view, LinearLayout.LayoutParams(-1, dp(height)).apply {
            setMargins(0, dp(4), 0, dp(4))
        })
    }

    private fun addLabel(label: String, color: Int = text) {
        root.addView(TextView(this).apply {
            this.text = label
            textSize = 13.5f
            setTextColor(color)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(dp(4), dp(7), dp(4), dp(2))
        })
    }

    private fun makeHeader(title: String, subtitle: String? = null, topColor: Int = blueDark, bottomColor: Int = blue): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = gradient(topColor, bottomColor, 24)
            setPadding(dp(18), dp(18), dp(18), dp(18))
            elevation = dp(4).toFloat()
        }
        card.addView(ImageView(this).apply {
            setImageResource(R.drawable.app_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            contentDescription = "لوگوی حسابداری مشترک"
        }, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, 0, 0, dp(5)) })
        card.addView(TextView(this).apply {
            text = title
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.RIGHT
        })
        subtitle?.let { sub ->
            card.addView(TextView(this).apply {
                text = sub
                textSize = 13.5f
                setTextColor(Color.rgb(226, 236, 250))
                gravity = Gravity.RIGHT
                setPadding(0, dp(6), 0, 0)
            })
        }
        return card
    }

    private fun base(title: String, subtitle: String? = null, topColor: Int = blueDark, bottomColor: Int = blue) {
        root = findViewById(R.id.root)
        root.removeAllViews()
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setBackgroundColor(bg)
        root.setPadding(dp(14), dp(14), dp(14), dp(28))
        root.addView(makeHeader(title, subtitle, topColor, bottomColor), LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, 0, 0, dp(12))
        })
    }

    private fun sectionCard(title: String, subtitle: String? = null, color: Int = blue): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.WHITE, 18, Color.rgb(228, 234, 244))
            elevation = dp(2).toFloat()
        }
        val titleView = TextView(this).apply {
            text = title
            textSize = 15.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(color)
            gravity = Gravity.RIGHT
        }
        card.addView(titleView)
        subtitle?.let {
            card.addView(TextView(this).apply {
                text = it
                textSize = 12.5f
                setTextColor(muted)
                gravity = Gravity.RIGHT
                setPadding(0, dp(3), 0, 0)
            })
        }
        return card
    }

    private fun addSectionCard(card: LinearLayout) {
        root.addView(card, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, dp(6), 0, dp(6))
        })
    }

    private fun metricCard(title: String, value: Long, color: Int, light: Int): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(light, 18)
            setPadding(dp(13), dp(12), dp(13), dp(12))
        }
        card.addView(TextView(this).apply {
            text = title
            textSize = 12.5f
            setTextColor(muted)
            gravity = Gravity.RIGHT
        })
        card.addView(TextView(this).apply {
            text = "${fmt(value)} تومان"
            textSize = 17.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(color)
            gravity = Gravity.RIGHT
            setPadding(0, dp(5), 0, 0)
        })
        return card
    }

    private fun actionButton(title: String, subtitle: String, color: Int, action: () -> Unit): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.WHITE, 18, Color.rgb(226, 232, 242))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            elevation = dp(2).toFloat()
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        card.addView(TextView(this).apply {
            text = title
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(color)
            gravity = Gravity.RIGHT
        })
        card.addView(TextView(this).apply {
            text = subtitle
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, 0)
        })
        return card
    }

    private fun addActionGrid(items: List<Triple<String, String, () -> Unit>>) {
        val grid = GridLayout(this).apply {
            columnCount = 2
            rowCount = (items.size + 1) / 2
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        items.forEach { (title, subtitle, action) ->
            grid.addView(actionButton(title, subtitle, if (title.contains("هزینه")) red else if (title.contains("فاکتور")) purple else blue, action), GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            })
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, dp(2), 0, dp(8))
        })
    }

    private fun loginButton(text: String, action: () -> Unit) {
        val button = Button(this).apply {
            this.text = text
            textSize = 15.5f
            isAllCaps = false
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(blue, 18)
            elevation = dp(2).toFloat()
            setOnClickListener { action() }
        }
        addView(button, 56)
    }

    private fun spinner(items: Array<String>): Spinner = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        background = rounded(Color.WHITE, 14, Color.rgb(222, 229, 241))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }.also { addView(it) }

    private fun showLogin() {
        registerRenderer { showLogin() }
        base("حسابداری مشترک", "ورود به حساب Firebase برای همگام‌سازی دو گوشی", blueDark, blue)
        val info = sectionCard("ورود امن", "همان ایمیل و رمز Firebase که خودت ساخته‌ای")
        info.addView(TextView(this).apply {
            text = "رمز این برنامه با رمز Gmail یکی نیست؛ همان رمزی را وارد کن که در Firebase Authentication برای این کاربر تعیین کردی."
            textSize = 12.5f
            setTextColor(muted)
            gravity = Gravity.RIGHT
            setPadding(0, dp(8), 0, 0)
        })
        addSectionCard(info)
        addLabel("ایمیل")
        val email = field("ایمیل حساب Firebase")
        addView(email)
        addLabel("رمز عبور")
        val password = field("رمز عبور").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        addView(password)
        loginButton("ورود به حساب") {
            val e = email.text.toString().trim()
            val p = password.text.toString()
            if (e.isBlank() || p.isBlank()) {
                toast("ایمیل و رمز را کامل وارد کن")
                return@loginButton
            }
            auth.signInWithEmailAndPassword(e, p)
                .addOnSuccessListener {
                    toast("ورود موفق بود")
                    startCloudSync()
                }
                .addOnFailureListener {
                    toast("ورود ناموفق است؛ اطلاعات ورود را بررسی کن")
                }
        }
    }

    private fun startCloudSync() {
        if (auth.currentUser == null) {
            showLogin()
            return
        }
        fullSyncStarted = false
        legacyMigrationRunning = false
        syncBootstrapRunning = true
        syncError = null
        syncOk = false
        attachCloudListeners()
        touchSyncMeta()
        showHome()
        migrateLegacyCloudData {
            fullSyncStarted = false
            performFullSync()
        }
    }

    private fun attachCloudListeners() {
        txListener?.remove()
        supplierListener?.remove()
        categoryListener?.remove()

        txListener = cloud.collection("transactions")
            .whereEqualTo("workspaceId", workspaceId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    markSyncError("تراکنش‌ها", error)
                    scheduleSyncRetry()
                    return@addSnapshotListener
                }
                markSyncSuccess()
                for (change in snapshot.documentChanges) {
                    val doc = change.document
                    if (doc.getString("workspaceId") != workspaceId) continue
                    val cloudId = doc.id
                    when (change.type) {
                        DocumentChange.Type.REMOVED -> {
                            db.deleteByCloudId(cloudId, createTombstone = true)
                        }
                        else -> {
                            val type = doc.getString("type") ?: continue
                            val date = doc.getString("date") ?: continue
                            val branchName = doc.getString("branch") ?: continue
                            val serverUpdatedAt = firestoreUpdatedAtMillis(doc)
                            val clientUpdatedAt = doc.getLong("clientUpdatedAt") ?: serverUpdatedAt ?: 0L
                            val updatedBy = doc.getString("updatedBy") ?: ""
                            if (!db.shouldApplyCloud(cloudId, clientUpdatedAt, updatedBy, auth.currentUser?.uid ?: "")) {
                                // Keep a newer unsent local version. It will be pushed below.
                                continue
                            }
                            db.upsertCloud(
                                cloudId = cloudId,
                                date = date,
                                branch = branchName,
                                type = type,
                                desc = doc.getString("desc") ?: "",
                                account = doc.getString("account"),
                                party = doc.getString("party"),
                                amount = doc.getLong("amount") ?: 0L,
                                expense = doc.getLong("expense") ?: 0L,
                                linkCloudId = doc.getString("linkCloudId"),
                                updatedAt = clientUpdatedAt,
                                updatedBy = updatedBy
                            )
                        }
                    }
                }
                uploadPendingLocalData()
                requestScreenRefresh()
            }

        supplierListener = cloud.collection("suppliers")
            .whereEqualTo("workspaceId", workspaceId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    markSyncError("فروشنده‌ها", error)
                    scheduleSyncRetry()
                    return@addSnapshotListener
                }
                markSyncSuccess()
                for (change in snapshot.documentChanges) {
                    val doc = change.document
                    if (change.type == DocumentChange.Type.REMOVED) {
                        db.deleteSupplierByCloudId(doc.id)
                        continue
                    }
                    if (doc.getString("workspaceId") != workspaceId) continue
                    val b = doc.getString("branch") ?: continue
                    val n = doc.getString("name") ?: continue
                    val updatedAt = doc.getLong("clientUpdatedAt") ?: firestoreUpdatedAtMillis(doc) ?: 0L
                    if (!db.shouldApplySupplierCloud(b, n, updatedAt)) continue
                    db.ensureSupplier(b, n, doc.id, doc.getBoolean("active") ?: true, updatedAt, false)
                }
                uploadPendingReferenceData()
                requestScreenRefresh()
            }

        categoryListener = cloud.collection("expense_categories")
            .whereEqualTo("workspaceId", workspaceId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    markSyncError("دسته‌های هزینه", error)
                    scheduleSyncRetry()
                    return@addSnapshotListener
                }
                markSyncSuccess()
                for (change in snapshot.documentChanges) {
                    val doc = change.document
                    if (change.type == DocumentChange.Type.REMOVED) {
                        db.deleteExpenseCategoryByCloudId(doc.id)
                        continue
                    }
                    if (doc.getString("workspaceId") != workspaceId) continue
                    val b = doc.getString("branch") ?: continue
                    val n = doc.getString("name") ?: continue
                    val updatedAt = doc.getLong("clientUpdatedAt") ?: firestoreUpdatedAtMillis(doc) ?: 0L
                    if (!db.shouldApplyCategoryCloud(b, n, updatedAt)) continue
                    db.addExpenseCategory(b, n, doc.id, doc.getBoolean("active") ?: true, updatedAt, false)
                }
                uploadPendingReferenceData()
                requestScreenRefresh()
            }
    }

    private fun firestoreUpdatedAtMillis(doc: com.google.firebase.firestore.DocumentSnapshot): Long? {
        val timestamp = doc.getTimestamp("updatedAt") ?: return doc.getLong("updatedAt")
        return timestamp.toDate().time
    }

    private fun markSyncSuccess() {
        syncOk = true
        syncError = null
        lastSyncAt = System.currentTimeMillis()
        requestScreenRefresh()
    }

    private fun markSyncError(area: String, error: Exception?) {
        syncOk = false
        syncError = when {
            error?.message?.contains("PERMISSION_DENIED", ignoreCase = true) == true ->
                "دسترسی Firestore رد شد؛ Rules منتشر نشده یا ورود کاربر مجاز نیست"
            error != null -> "خطای $area: ${error.localizedMessage ?: "نامشخص"}"
            else -> "خطای همگام‌سازی $area"
        }
        requestScreenRefresh()
    }

    private fun scheduleSyncRetry() {
        if (syncRetryScheduled || auth.currentUser == null) return
        syncRetryScheduled = true
        syncHandler.postDelayed({
            syncRetryScheduled = false
            if (auth.currentUser != null) {
                uploadPendingLocalData()
                uploadPendingReferenceData()
                touchSyncMeta()
            }
        }, 10_000L)
    }

    private fun touchSyncMeta() {
        val uid = auth.currentUser?.uid ?: return
        cloud.collection("sync_meta").document(workspaceId).set(
            mapOf(
                "workspaceId" to workspaceId,
                "lastUserUid" to uid,
                "lastUserEmail" to (auth.currentUser?.email ?: ""),
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        ).addOnSuccessListener {
            markSyncSuccess()
        }.addOnFailureListener { e ->
            markSyncError("اتصال Firebase", e)
            scheduleSyncRetry()
        }
    }

    private fun migrateLegacyCloudData(onComplete: () -> Unit) {
        if (auth.currentUser == null || legacyMigrationRunning) {
            onComplete()
            return
        }
        legacyMigrationRunning = true
        val collections = listOf("transactions", "suppliers", "expense_categories")
        migrateLegacyCollection(collections, 0, onComplete)
    }

    private fun migrateLegacyCollection(collections: List<String>, index: Int, onComplete: () -> Unit) {
        if (index >= collections.size) {
            legacyMigrationRunning = false
            syncBootstrapRunning = false
            markSyncSuccess()
            onComplete()
            return
        }
        val name = collections[index]
        cloud.collection(name).get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                val legacy = snapshot.documents.filter { doc ->
                    val value = doc.getString("workspaceId")?.trim()
                    value == null || value.isEmpty() || value == "."
                }
                commitLegacyWorkspaceBatches(name, legacy, 0) {
                    migrateLegacyCollection(collections, index + 1, onComplete)
                }
            }
            .addOnFailureListener { e ->
                legacyMigrationRunning = false
                syncBootstrapRunning = false
                markSyncError("انتقال داده‌های قدیمی", e)
                scheduleSyncRetry()
                onComplete()
            }
    }

    private fun commitLegacyWorkspaceBatches(
        collectionName: String,
        docs: List<com.google.firebase.firestore.DocumentSnapshot>,
        start: Int,
        onComplete: () -> Unit
    ) {
        if (start >= docs.size) {
            onComplete()
            return
        }
        val end = minOf(start + 450, docs.size)
        val batch = cloud.batch()
        docs.subList(start, end).forEach { doc ->
            batch.set(
                cloud.collection(collectionName).document(doc.id),
                mapOf("workspaceId" to workspaceId),
                SetOptions.merge()
            )
        }
        batch.commit()
            .addOnSuccessListener {
                commitLegacyWorkspaceBatches(collectionName, docs, end, onComplete)
            }
            .addOnFailureListener { e ->
                legacyMigrationRunning = false
                syncBootstrapRunning = false
                markSyncError("انتقال داده‌های قدیمی", e)
                scheduleSyncRetry()
                onComplete()
            }
    }

    private fun performFullSync() {
        if (fullSyncStarted || auth.currentUser == null) return
        fullSyncStarted = true

        cloud.collection("transactions").whereEqualTo("workspaceId", workspaceId).get(Source.SERVER)
            .addOnSuccessListener { txSnapshot ->
                markSyncSuccess()
                txSnapshot.documents.forEach { doc ->
                    val type = doc.getString("type") ?: return@forEach
                    val date = doc.getString("date") ?: return@forEach
                    val branchName = doc.getString("branch") ?: return@forEach
                    val cloudId = doc.id
                    val serverUpdatedAt = firestoreUpdatedAtMillis(doc)
                    val clientUpdatedAt = doc.getLong("clientUpdatedAt") ?: serverUpdatedAt ?: 0L
                    val updatedBy = doc.getString("updatedBy") ?: ""
                    if (!db.shouldApplyCloud(cloudId, clientUpdatedAt, updatedBy, auth.currentUser?.uid ?: "")) return@forEach
                    db.upsertCloud(
                        cloudId = cloudId,
                        date = date,
                        branch = branchName,
                        type = type,
                        desc = doc.getString("desc") ?: "",
                        account = doc.getString("account"),
                        party = doc.getString("party"),
                        amount = doc.getLong("amount") ?: 0L,
                        expense = doc.getLong("expense") ?: 0L,
                        linkCloudId = doc.getString("linkCloudId"),
                        updatedAt = clientUpdatedAt,
                        updatedBy = updatedBy
                    )
                }

                cloud.collection("suppliers").whereEqualTo("workspaceId", workspaceId).get(Source.SERVER)
                    .addOnSuccessListener { supplierSnapshot ->
                        markSyncSuccess()
                        supplierSnapshot.documents.forEach { doc ->
                            val b = doc.getString("branch") ?: return@forEach
                            val n = doc.getString("name") ?: return@forEach
                            val updatedAt = doc.getLong("clientUpdatedAt") ?: firestoreUpdatedAtMillis(doc) ?: 0L
                            if (!db.shouldApplySupplierCloud(b, n, updatedAt)) return@forEach
                            db.ensureSupplier(b, n, doc.id, doc.getBoolean("active") ?: true, updatedAt, false)
                        }

                        cloud.collection("expense_categories").whereEqualTo("workspaceId", workspaceId).get(Source.SERVER)
                            .addOnSuccessListener { categorySnapshot ->
                                markSyncSuccess()
                                categorySnapshot.documents.forEach { doc ->
                                    val b = doc.getString("branch") ?: return@forEach
                                    val n = doc.getString("name") ?: return@forEach
                                    val updatedAt = doc.getLong("clientUpdatedAt") ?: firestoreUpdatedAtMillis(doc) ?: 0L
                                    if (db.shouldApplyCategoryCloud(b, n, updatedAt)) {
                                        db.addExpenseCategory(b, n, doc.id, doc.getBoolean("active") ?: true, updatedAt, false)
                                    }
                                }
                                syncBootstrapRunning = false
                                markSyncSuccess()
                                uploadPendingLocalData()
                                uploadPendingReferenceData()
                                requestScreenRefresh()
                                toast("همگام‌سازی ابری انجام شد")
                            }
                            .addOnFailureListener { e ->
                                syncBootstrapRunning = false
                                markSyncError("دسته‌ها", e)
                                scheduleSyncRetry()
                            }
                    }
                    .addOnFailureListener { e ->
                        syncBootstrapRunning = false
                        markSyncError("فروشنده‌ها", e)
                        scheduleSyncRetry()
                    }
            }
            .addOnFailureListener { e ->
                syncBootstrapRunning = false
                markSyncError("تراکنش‌ها", e)
                scheduleSyncRetry()
            }
    }

    private fun uploadPendingLocalData() {
        if (auth.currentUser == null || syncBootstrapRunning) return
        uploadPendingDeletes()
        db.dirtyRows().forEach { uploadRow(it) }
    }

    private fun uploadPendingDeletes() {
        if (auth.currentUser == null || syncBootstrapRunning) return
        db.tombstones().forEach { cloudId ->
            cloud.collection("transactions").document(cloudId).delete()
                .addOnSuccessListener { db.removeTombstone(cloudId); markSyncSuccess() }
                .addOnFailureListener { e -> markSyncError("حذف تراکنش", e); scheduleSyncRetry() }
        }
    }

    private fun uploadPendingReferenceData() {
        if (auth.currentUser == null || syncBootstrapRunning) return
        arrayOf("آرایشی", "حرم").forEach { b ->
            db.dirtySuppliers(b).forEach { uploadSupplier(b, it) }
            db.dirtyCategories(b).forEach { uploadCategory(b, it) }
        }
    }

    private fun uploadRow(row: Row) {
        val id = row.cloudId ?: UUID.randomUUID().toString().also { db.setCloudId(row.id, it) }
        val data = hashMapOf<String, Any?>(
            "workspaceId" to workspaceId,
            "date" to row.date,
            "branch" to row.branch,
            "type" to row.type,
            "desc" to row.desc,
            "account" to row.account,
            "party" to row.party,
            "amount" to row.amount,
            "expense" to row.expense,
            "linkCloudId" to row.linkCloudId,
            "clientUpdatedAt" to row.updatedAt,
            "updatedBy" to (auth.currentUser?.uid ?: ""),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        cloud.collection("transactions").document(id).set(data, SetOptions.merge())
            .addOnSuccessListener {
                db.markClean(row.id)
                markSyncSuccess()
            }
            .addOnFailureListener { e ->
                markSyncError("ثبت تراکنش", e)
                scheduleSyncRetry()
            }
    }

    private fun uploadRows(rows: List<Row>) {
        if (rows.isEmpty()) return
        val validRows = rows.filter { it.cloudId != null }
        if (validRows.isEmpty()) return
        val batch = cloud.batch()
        validRows.forEach { row ->
            val id = row.cloudId!!
            batch.set(
                cloud.collection("transactions").document(id),
                mapOf(
                    "workspaceId" to workspaceId,
                    "date" to row.date,
                    "branch" to row.branch,
                    "type" to row.type,
                    "desc" to row.desc,
                    "account" to row.account,
                    "party" to row.party,
                    "amount" to row.amount,
                    "expense" to row.expense,
                    "linkCloudId" to row.linkCloudId,
                    "clientUpdatedAt" to row.updatedAt,
                    "updatedBy" to (auth.currentUser?.uid ?: ""),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
        batch.commit()
            .addOnSuccessListener {
                validRows.forEach { db.markClean(it.id) }
                markSyncSuccess()
            }
            .addOnFailureListener { e ->
                markSyncError("ثبت تراکنش‌ها", e)
                scheduleSyncRetry()
            }
    }

    private fun uploadSupplier(branchName: String, name: String) {
        val existingId = db.supplierCloudId(branchName, name)
        val id = existingId ?: stableId("supplier|$branchName|$name")
        if (existingId == null) db.ensureSupplier(branchName, name, id, true, System.currentTimeMillis(), true)
        val data = mapOf(
            "workspaceId" to workspaceId,
            "branch" to branchName,
            "name" to name,
            "active" to db.supplierActive(branchName, name),
            "clientUpdatedAt" to db.supplierUpdatedAt(branchName, name),
            "updatedBy" to (auth.currentUser?.uid ?: ""),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        cloud.collection("suppliers").document(id).set(data, SetOptions.merge())
            .addOnSuccessListener {
                db.markSupplierClean(branchName, name)
                markSyncSuccess()
            }
            .addOnFailureListener { e ->
                markSyncError("فروشنده", e)
                scheduleSyncRetry()
            }
    }

    private fun uploadCategory(branchName: String, name: String) {
        val existingId = db.categoryCloudId(branchName, name)
        val id = existingId ?: stableId("category|$branchName|$name")
        if (existingId == null) db.addExpenseCategory(branchName, name, id, true, System.currentTimeMillis(), true)
        val data = mapOf(
            "workspaceId" to workspaceId,
            "branch" to branchName,
            "name" to name,
            "active" to db.categoryActive(branchName, name),
            "clientUpdatedAt" to db.categoryUpdatedAt(branchName, name),
            "updatedBy" to (auth.currentUser?.uid ?: ""),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        cloud.collection("expense_categories").document(id).set(data, SetOptions.merge())
            .addOnSuccessListener {
                db.markCategoryClean(branchName, name)
                markSyncSuccess()
            }
            .addOnFailureListener { e ->
                markSyncError("دسته هزینه", e)
                scheduleSyncRetry()
            }
    }

    private fun syncStatusText(): String = when {
        syncError != null -> "همگام‌سازی: خطا"
        syncOk -> if (lastSyncAt > 0L) "همگام‌سازی: متصل • ${SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(lastSyncAt))}" else "همگام‌سازی: متصل"
        else -> "همگام‌سازی: در حال اتصال"
    }

    private fun requestScreenRefresh() {
        if (currentRenderer == null || refreshScheduled) return
        refreshScheduled = true
        syncHandler.postDelayed({
            refreshScheduled = false
            if (!isFinishing && !isDestroyed && hasWindowFocus()) {
                currentRenderer?.invoke()
            }
        }, 250L)
    }

    private fun registerRenderer(renderer: () -> Unit) {
        currentRenderer = renderer
    }

    private fun stableId(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun showHome() {
        registerRenderer { showHome() }
        base("حسابداری مشترک", "داشبورد مالی دو شعبه • ${syncStatusText()}", blueDark, blue)

        val totalSales = db.sumType("آرایشی", "SALE") + db.sumType("حرم", "SALE")
        val totalExpense = db.sumType("آرایشی", "EXPENSE") + db.sumType("حرم", "EXPENSE")
        val totalDebt = db.supplierBalances("آرایشی").values.sum() + db.supplierBalances("حرم").values.sum()
        val totalBalance = accountsFor("آرایشی").sumOf { db.balance("آرایشی", it) } + accountsFor("حرم").sumOf { db.balance("حرم", it) }

        val metrics = GridLayout(this).apply {
            columnCount = 2
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        listOf(
            metricCard("فروش کل", totalSales, green, lightGreen),
            metricCard("هزینه کل", totalExpense, red, lightRed),
            metricCard("بدهی فروشنده‌ها", totalDebt, purple, lightPurple),
            metricCard("موجودی حساب‌ها", totalBalance, blue, lightBlue)
        ).forEach { card ->
            metrics.addView(card, GridLayout.LayoutParams().apply {
                width = 0; height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            })
        }
        root.addView(metrics)

        val branches = sectionCard("شعبه‌ها", "برای ورود به عملیات همان شعبه")
        addBranchButton(branches, "آرایشی", blue) { branch = "آرایشی"; showBranch() }
        addBranchButton(branches, "حرم", purple) { branch = "حرم"; showBranch() }
        addSectionCard(branches)

        val syncCard = sectionCard("همگام‌سازی دو گوشی", syncError ?: if (syncOk) "اتصال Firebase برقرار است و تغییرات دوطرفه ارسال می‌شود" else "در حال بررسی اتصال...", if (syncError != null) red else green)
        val syncButtonText = if (syncError != null) "🔄 تلاش دوباره" else "☁️ همگام‌سازی الآن"
        syncCard.addView(actionButton(syncButtonText, "دریافت داده‌های ابری و ارسال تغییرات این گوشی", blue) {
            syncError = null
            touchSyncMeta()
            fullSyncStarted = false
            performFullSync()
            uploadPendingLocalData()
            uploadPendingReferenceData()
            toast("همگام‌سازی در حال انجام است")
        }, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(6), 0, 0) })
        addSectionCard(syncCard)

        val quick = sectionCard("دسترسی سریع", "گزارش و تاریخچه")
        quick.addView(actionButton("📊 گزارش کلی", "فروش، خرید، هزینه و جریان نقدی", purple) { showReport() }, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(6), 0, 0) })
        quick.addView(actionButton("📜 همه تراکنش‌ها", "مشاهده، ویرایش و حذف", blueDark) { showHistory() }, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(6), 0, 0) })
        quick.addView(actionButton("🚪 خروج از حساب", "خروج از Firebase در این گوشی", red) { signOut() }, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(6), 0, 0) })
        addSectionCard(quick)
    }

    private fun addBranchButton(parent: LinearLayout, name: String, color: Int, action: () -> Unit) {
        val button = Button(this).apply {
            text = "${if (name == "حرم") "🕌" else "💄"}  $name"
            textSize = 15f
            isAllCaps = false
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(color, 15)
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(0, dp(6), 0, 0) })
    }

    private fun accountsFor(branchName: String): Array<String> = if (branchName == "حرم") {
        arrayOf("صندوق نقدی حرم", "بانک پاسارگاد حرم", "بانک سامان حرم")
    } else {
        arrayOf("صندوق نقدی آرایشی", "بانک پاسارگاد آرایشی", "بانک ملی آرایشی")
    }

    private fun accounts(): Array<String> = accountsFor(branch)

    private fun showBranch() {
        registerRenderer { showBranch() }
        val accent = if (branch == "آرایشی") blue else purple
        base(branch, "مدیریت مالی حرفه‌ای شعبه ${branch}", blueDark, accent)
        val total = accounts().sumOf { db.balance(branch, it) }
        val debt = db.supplierBalances(branch).values.sum()
        val cards = GridLayout(this).apply { columnCount = 2; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        listOf(
            metricCard("موجودی فعلی", total, accent, if (accent == purple) lightPurple else lightBlue),
            metricCard("بدهی فروشنده‌ها", debt, if (debt > 0) red else green, if (debt > 0) lightRed else lightGreen)
        ).forEach { card ->
            cards.addView(card, GridLayout.LayoutParams().apply { width = 0; height = ViewGroup.LayoutParams.WRAP_CONTENT; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        root.addView(cards)

        addSectionCard(sectionCard("عملیات روزانه", "ورود سریع به ثبت‌های اصلی", accent))
        addActionGrid(listOf(
            Triple("💰 ثبت فروش روزانه", "فروش به تفکیک حساب", { showSales() }),
            Triple("💸 هزینه‌ها", "ثبت و تاریخچه هزینه", { showExpenses() }),
            Triple("🧾 فاکتور خرید", "نقدی یا نسیه", { showPurchase() }),
            Triple("🏢 فروشنده‌ها", "دفتر مستقل هر فروشنده", { showSuppliers() })
        ))

        addSectionCard(sectionCard("حساب‌ها و پرداخت‌ها", "موجودی، پرداخت بدهی و انتقال", accent))
        addActionGrid(listOf(
            Triple("💳 پرداخت بدهی فروشنده", "ثبت پرداخت عادی", { showSupplierPayment() }),
            Triple("🔄 انتقال بین حساب‌ها", "جابجایی پول بین حساب‌ها", { showTransfer() }),
            Triple("🏦 موجودی حساب‌ها", "جزئیات حساب‌های شعبه", { showBalances() }),
            Triple("📜 تاریخچه شعبه", "تمام تراکنش‌های این شعبه", { showHistory(branch) })
        ))

        addSectionCard(sectionCard("شرکا", "برداشت جداگانه هر شریک", blueDark))
        addActionGrid(listOf(
            Triple("👤 برداشت محمدرضا", "ثبت برداشت شریک", { showWithdrawal("محمدرضا") }),
            Triple("👤 برداشت علیرضا", "ثبت برداشت شریک", { showWithdrawal("علیرضا") })
        ))

        val back = Button(this).apply { text = "⬅ برگشت به داشبورد"; textSize = 14.5f; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(Color.GRAY, 15); setOnClickListener { showHome() } }
        addView(back, 54)
    }

    private fun showSales() {
        registerRenderer { showSales() }
        base("ثبت فروش روزانه", "شعبه $branch — مبلغ فروش را برای هر حساب دریافت‌کننده وارد کن", blueDark, blue)
        val card = sectionCard("فروش امروز", "هر حساب مبلغ جداگانه دارد", green)
        val amountFields = accounts().map { accountName ->
            val input = moneyInput(accountName)
            card.addView(input, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0, dp(6), 0, 0) })
            input
        }
        root.addView(card)
        val save = Button(this).apply { text = "ثبت فروش"; isAllCaps = false; textSize = 15.5f; setTextColor(Color.WHITE); background = rounded(green, 16); setOnClickListener {
            val values = amountFields.map { moneyValue(it) }
            if (values.sum() <= 0L) { toast("حداقل یک مبلغ فروش وارد کن"); return@setOnClickListener }
            val rows = mutableListOf<Row>()
            for (i in values.indices) if (values[i] > 0L) rows += db.add("SALE", branch, "فروش روزانه", accounts()[i], null, values[i], 0L)
            uploadRows(rows)
            toast("فروش ${fmt(values.sum())} تومان ثبت شد")
            showBranch()
        } }
        addView(save, 56)
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; background = rounded(Color.GRAY, 15); setTextColor(Color.WHITE); setOnClickListener { showBranch() } }, 52)
    }

    private fun showExpenses() {
        registerRenderer { showExpenses() }
        base("هزینه‌ها", "شعبه $branch — ثبت و مشاهده جداگانه هزینه‌ها", blueDark, red)
        addSectionCard(sectionCard("عملیات هزینه", "همه هزینه‌ها با حساب پرداخت‌کننده ثبت می‌شوند", red))
        addActionGrid(listOf(
            Triple("➕ ثبت هزینه جدید", "هزینه از حساب انتخابی کم می‌شود", { showExpense() }),
            Triple("📋 هزینه‌های ثبت‌شده", "تاریخچه هزینه‌های شعبه", { showExpenseHistory() }),
            Triple("⚙ دسته‌های هزینه", "افزودن دسته جدید", { manageExpenseCategories() })
        ))
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(Color.GRAY, 15); setOnClickListener { showBranch() } }, 52)
    }

    private fun showExpense() {
        registerRenderer { showExpense() }
        base("ثبت هزینه", "شعبه $branch — تاریخ: ${todayJalali()}", blueDark, red)
        addLabel("دسته هزینه")
        val categories = db.activeExpenseCategories(branch).toTypedArray()
        val cat = spinner(if (categories.isEmpty()) arrayOf("متفرقه") else categories)
        addLabel("شرح / توضیحات")
        val desc = field("مثلاً اجاره مهر ماه")
        addView(desc)
        addLabel("حساب پرداخت‌کننده")
        val paymentAccount = spinner(accounts())
        addLabel("مبلغ")
        val amount = moneyInput()
        addView(amount)
        addView(Button(this).apply { text = "ثبت هزینه"; isAllCaps = false; textSize = 15.5f; setTextColor(Color.WHITE); background = rounded(red, 16); setOnClickListener {
            val m = moneyValue(amount)
            if (m <= 0L) { toast("مبلغ را وارد کن"); return@setOnClickListener }
            if (db.balance(branch, paymentAccount.selectedItem.toString()) < m) { toast("موجودی حساب کافی نیست"); return@setOnClickListener }
            val description = if (desc.text.toString().trim().isBlank()) cat.selectedItem.toString() else "${cat.selectedItem}: ${desc.text}"
            val row = db.add("EXPENSE", branch, description, paymentAccount.selectedItem.toString(), null, 0L, m)
            uploadRows(listOf(row))
            toast("هزینه ثبت شد")
            showExpenses()
        } }, 56)
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(Color.GRAY, 15); setOnClickListener { showExpenses() } }, 52)
    }

    private fun showExpenseHistory() {
        registerRenderer { showExpenseHistory() }
        base("تاریخچه هزینه‌ها", "شعبه $branch", blueDark, red)
        val rows = db.rows(branch).filter { it.type == "EXPENSE" }
        if (rows.isEmpty()) addLabel("هنوز هزینه‌ای ثبت نشده") else rows.forEach { addHistoryCard(it, branch) }
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(Color.GRAY, 15); setOnClickListener { showExpenses() } }, 52)
    }

    private fun manageExpenseCategories() {
        registerRenderer { manageExpenseCategories() }
        base("دسته‌های هزینه", "شعبه $branch", blueDark, purple)
        db.expenseCategories(branch).forEach { name ->
            val status = if (db.categoryActive(branch, name)) "فعال" else "غیرفعال"
            val card = sectionCard("$name", "$status  •  نگه داشتن انگشت: ویرایش یا حذف", if (db.categoryActive(branch, name)) purple else muted)
            card.setOnLongClickListener { categoryActions(name); true }
            addSectionCard(card)
        }
        val input = field("نام دسته جدید")
        addView(input)
        addView(Button(this).apply { text = "＋ افزودن دسته هزینه"; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(purple, 15); setOnClickListener {
            val n = input.text.toString().trim()
            if (n.isBlank()) { toast("نام دسته را وارد کن"); return@setOnClickListener }
            db.addExpenseCategory(branch, n)
            uploadCategory(branch, n)
            toast("دسته اضافه شد")
            manageExpenseCategories()
        } }, 54)
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(Color.GRAY, 15); setOnClickListener { showExpenses() } }, 52)
    }

    private fun showPurchase() {
        registerRenderer { showPurchase() }
        base("فاکتور خرید", "شعبه $branch — تاریخ: ${todayJalali()}", blueDark, purple)
        val suppliers = db.activeSuppliers(branch).toTypedArray()
        val top = sectionCard("اطلاعات فاکتور", "فروشنده را از فهرست انتخاب کن یا یک فروشنده جدید اضافه کن", purple)
        val supplierSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, if (suppliers.isEmpty()) arrayOf("فروشنده‌ای ثبت نشده") else suppliers)
            background = rounded(Color.WHITE, 14, Color.rgb(222, 229, 241))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        top.addView(supplierSpinner, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(0, dp(7), 0, 0) })
        val newSupplier = field("فروشنده جدید (در صورت نیاز)")
        top.addView(newSupplier, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(0, dp(6), 0, 0) })
        addSectionCard(top)

        addLabel("مبلغ فاکتور")
        val amount = moneyInput()
        addView(amount)

        val cash = CheckBox(this).apply {
            text = "نقدی پرداخت میکنم"
            textSize = 15.5f
            isChecked = false
            gravity = Gravity.RIGHT
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        addView(cash, 50)

        addLabel("حساب پرداخت‌کننده — فقط در خرید نقدی")
        val account = spinner(accounts())
        account.isEnabled = false
        cash.setOnCheckedChangeListener { _, checked -> account.isEnabled = checked }

        addView(Button(this).apply { text = "ثبت فاکتور خرید"; isAllCaps = false; textSize = 15.5f; setTextColor(Color.WHITE); background = rounded(purple, 16); setOnClickListener {
            val m = moneyValue(amount)
            val typedSupplier = newSupplier.text.toString().trim()
            val selectedSupplier = if (suppliers.isEmpty()) "" else supplierSpinner.selectedItem.toString()
            val chosenSupplier = typedSupplier.ifBlank { selectedSupplier }
            if (chosenSupplier.isBlank() || chosenSupplier == "فروشنده‌ای ثبت نشده" || m <= 0L) { toast("فروشنده و مبلغ را کامل وارد کن"); return@setOnClickListener }

            db.ensureSupplier(branch, chosenSupplier)
            uploadSupplier(branch, chosenSupplier)

            if (!cash.isChecked) {
                val row = db.add("PURCHASE_CREDIT", branch, "فاکتور خرید", null, chosenSupplier, m, 0L)
                uploadRows(listOf(row))
                toast("فاکتور ثبت شد و ${fmt(m)} تومان به بدهی فروشنده اضافه شد")
            } else {
                val source = account.selectedItem.toString()
                if (db.balance(branch, source) < m) { toast("موجودی حساب کافی نیست"); return@setOnClickListener }
                val purchase = db.add("PURCHASE_CASH", branch, "فاکتور خرید نقدی", source, chosenSupplier, m, 0L)
                val payment = db.add("SUPPLIER_PAYMENT", branch, "پرداخت نقدی همان فاکتور", null, chosenSupplier, m, 0L, purchase.cloudId)
                uploadRows(listOf(purchase, payment))
                toast("فاکتور نقدی ثبت شد؛ پرداخت فروشنده هم ثبت شد و بدهی صفر می‌شود")
            }
            showBranch()
        } }, 56)
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(Color.GRAY, 15); setOnClickListener { showBranch() } }, 52)
    }

    private fun showSuppliers() {
        registerRenderer { showSuppliers() }
        base("فروشنده‌ها و شرکت‌ها", "شعبه $branch — برای مدیریت فروشنده روی کارت نگه دار", blueDark, purple)
        val list = db.suppliers(branch)
        if (list.isEmpty()) addLabel("هنوز فروشنده‌ای ثبت نشده")
        list.forEach { supplier ->
            val balance = db.supplierBalance(branch, supplier)
            val status = if (db.supplierActive(branch, supplier)) "فعال" else "غیرفعال"
            val card = sectionCard(supplier, "$status  •  بدهی ${fmt(balance)} تومان  •  خرید ${fmt(db.supplierPurchases(branch, supplier))}  •  پرداخت ${fmt(db.supplierPayments(branch, supplier))}", if (!db.supplierActive(branch, supplier)) muted else if (balance > 0) red else green)
            card.setOnClickListener { showSupplierDetail(supplier) }
            card.setOnLongClickListener { supplierActions(supplier); true }
            root.addView(card, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(5), 0, dp(5)) })
        }
        addView(Button(this).apply { text = "＋ افزودن فروشنده جدید"; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(blue, 15); setOnClickListener {
            val input = field("نام شخص / شرکت")
            AlertDialog.Builder(this@MainActivity)
                .setTitle("فروشنده جدید")
                .setView(input)
                .setNegativeButton("لغو", null)
                .setPositiveButton("ذخیره") { _, _ ->
                    val name = input.text.toString().trim()
                    if (name.isNotBlank()) {
                        db.ensureSupplier(branch, name)
                        uploadSupplier(branch, name)
                        showSuppliers()
                    }
                }.show()
        } }, 54)
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(Color.GRAY, 15); setOnClickListener { showBranch() } }, 52)
    }

    private fun supplierActions(supplier: String) {
        val input = field("نام جدید")
        input.setText(supplier)
        AlertDialog.Builder(this)
            .setTitle("مدیریت فروشنده")
            .setItems(arrayOf("✏️ ویرایش نام", "⏺️ فعال/غیرفعال کردن", "🗑️ حذف فروشنده", "لغو")) { _, which ->
                when (which) {
                    0 -> AlertDialog.Builder(this).setTitle("ویرایش فروشنده").setView(input)
                        .setNegativeButton("لغو", null)
                        .setPositiveButton("ذخیره") { _, _ ->
                            val newName = input.text.toString().trim()
                            if (newName.isBlank() || newName == supplier) return@setPositiveButton
                            if (db.suppliers(branch).any { it == newName }) { toast("این نام قبلاً ثبت شده است"); return@setPositiveButton }
                            val oldCloud = db.renameSupplier(branch, supplier, newName)
                            db.setSupplierCloudId(branch, newName, stableId("supplier|$branch|$newName"))
                            uploadSupplier(branch, newName)
                            db.rows(branch).filter { it.party == newName }.let { uploadRows(it) }
                            oldCloud?.let { cloud.collection("suppliers").document(it).delete() }
                            toast("نام فروشنده و دفتر حساب و تراکنش‌های مرتبط ویرایش شد")
                            showSuppliers()
                        }.show()
                    1 -> {
                        val active = db.toggleSupplier(branch, supplier)
                        uploadSupplier(branch, supplier)
                        toast(if (active) "فروشنده فعال شد" else "فروشنده غیرفعال شد")
                        showSuppliers()
                    }
                    2 -> {
                        if (db.hasSupplierTransactions(branch, supplier)) {
                            if (db.supplierActive(branch, supplier)) {
                                db.toggleSupplier(branch, supplier)
                                uploadSupplier(branch, supplier)
                            }
                            toast("این فروشنده سابقه مالی دارد؛ حذف کامل نشد و برای حفظ سابقه غیرفعال شد.")
                            showSuppliers()
                            return@setItems
                        }
                        AlertDialog.Builder(this).setTitle("حذف فروشنده؟")
                            .setMessage("این فروشنده هیچ تراکنشی ندارد و حذف خواهد شد.")
                            .setNegativeButton("لغو", null)
                            .setPositiveButton("حذف") { _, _ ->
                                val cloudId = db.supplierCloudId(branch, supplier)
                                if (cloudId == null) {
                                    db.deleteSupplier(branch, supplier)
                                    toast("فروشنده حذف شد")
                                    showSuppliers()
                                } else {
                                    cloud.collection("suppliers").document(cloudId).delete()
                                        .addOnSuccessListener {
                                            db.deleteSupplier(branch, supplier)
                                            markSyncSuccess()
                                            toast("فروشنده حذف شد")
                                            showSuppliers()
                                        }
                                        .addOnFailureListener { e ->
                                            markSyncError("حذف فروشنده", e)
                                            toast("حذف از Firebase انجام نشد؛ فروشنده حفظ شد")
                                        }
                                }
                            }.show()
                    }
                }
            }.show()
    }

    private fun categoryActions(name: String) {
        val input = field("نام دسته جدید")
        input.setText(name)
        AlertDialog.Builder(this)
            .setTitle("مدیریت دسته هزینه")
            .setItems(arrayOf("✏️ ویرایش نام", "⏺️ فعال/غیرفعال کردن", "🗑️ حذف دسته", "لغو")) { _, which ->
                when (which) {
                    0 -> AlertDialog.Builder(this).setTitle("ویرایش دسته").setView(input)
                        .setNegativeButton("لغو", null)
                        .setPositiveButton("ذخیره") { _, _ ->
                            val newName = input.text.toString().trim()
                            if (newName.isBlank() || newName == name) return@setPositiveButton
                            if (db.expenseCategories(branch).any { it == newName }) { toast("این دسته قبلاً ثبت شده است"); return@setPositiveButton }
                            val oldCloud = db.renameExpenseCategory(branch, name, newName)
                            db.setCategoryCloudId(branch, newName, stableId("category|$branch|$newName"))
                            uploadCategory(branch, newName)
                            oldCloud?.let { cloud.collection("expense_categories").document(it).delete() }
                            toast("دسته هزینه ویرایش شد")
                            manageExpenseCategories()
                        }.show()
                    1 -> {
                        val active = db.toggleExpenseCategory(branch, name)
                        uploadCategory(branch, name)
                        toast(if (active) "دسته فعال شد" else "دسته غیرفعال شد")
                        manageExpenseCategories()
                    }
                    2 -> {
                        if (db.hasExpenseCategoryTransactions(branch, name)) {
                            if (db.categoryActive(branch, name)) {
                                db.toggleExpenseCategory(branch, name)
                                uploadCategory(branch, name)
                            }
                            toast("این دسته در تراکنش‌های قبلی استفاده شده؛ حذف کامل نشد و غیرفعال شد.")
                            manageExpenseCategories()
                            return@setItems
                        }
                        AlertDialog.Builder(this).setTitle("حذف دسته؟")
                            .setMessage("این دسته هیچ تراکنش ثبت‌شده‌ای ندارد و حذف خواهد شد.")
                            .setNegativeButton("لغو", null)
                            .setPositiveButton("حذف") { _, _ ->
                                val cloudId = db.categoryCloudId(branch, name)
                                if (cloudId == null) {
                                    db.deleteExpenseCategory(branch, name)
                                    toast("دسته حذف شد")
                                    manageExpenseCategories()
                                } else {
                                    cloud.collection("expense_categories").document(cloudId).delete()
                                        .addOnSuccessListener {
                                            db.deleteExpenseCategory(branch, name)
                                            markSyncSuccess()
                                            toast("دسته حذف شد")
                                            manageExpenseCategories()
                                        }
                                        .addOnFailureListener { e ->
                                            markSyncError("حذف دسته هزینه", e)
                                            toast("حذف از Firebase انجام نشد؛ دسته حفظ شد")
                                        }
                                }
                            }.show()
                    }
                }
            }.show()
    }

    private fun showSupplierDetail(supplier: String) {
        registerRenderer { showSupplierDetail(supplier) }
        val balance = db.supplierBalance(branch, supplier)
        base(supplier, "دفتر حساب فروشنده — شعبه $branch", blueDark, if (balance > 0) red else green)
        val metrics = GridLayout(this).apply { columnCount = 2; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        listOf(
            metricCard("بدهی فعلی", balance, if (balance > 0) red else green, if (balance > 0) lightRed else lightGreen),
            metricCard("مجموع خرید", db.supplierPurchases(branch, supplier), purple, lightPurple),
            metricCard("مجموع پرداخت", db.supplierPayments(branch, supplier), green, lightGreen)
        ).forEach { card ->
            metrics.addView(card, GridLayout.LayoutParams().apply { width = 0; height = ViewGroup.LayoutParams.WRAP_CONTENT; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        root.addView(metrics)
        addLabel("گردش کامل حساب", purple)
        val rows = db.rows(branch).filter { it.party == supplier && it.type in setOf("PURCHASE_CREDIT", "PURCHASE_CASH", "SUPPLIER_PAYMENT") }
        if (rows.isEmpty()) addLabel("گردشی ثبت نشده") else rows.forEach { addHistoryCard(it, branch) }
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(Color.GRAY, 15); setOnClickListener { showSuppliers() } }, 52)
    }

    private fun showSupplierPayment() {
        registerRenderer { showSupplierPayment() }
        base("پرداخت بدهی فروشنده", "شعبه $branch — پرداخت عادی در اینجا ثبت می‌شود", blueDark, green)
        val suppliers = db.activeSuppliers(branch).toTypedArray()
        if (suppliers.isEmpty()) {
            addLabel("ابتدا برای یک فروشنده فاکتور خرید ثبت کن")
            addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; background = rounded(Color.GRAY, 15); setTextColor(Color.WHITE); setOnClickListener { showBranch() } }, 52)
            return
        }
        addLabel("فروشنده")
        val supplier = spinner(suppliers)
        addLabel("حساب پرداخت‌کننده")
        val account = spinner(accounts())
        addLabel("مبلغ پرداخت")
        val amount = moneyInput()
        addView(amount)
        addView(Button(this).apply { text = "ثبت پرداخت"; isAllCaps = false; textSize = 15.5f; background = rounded(green, 16); setTextColor(Color.WHITE); setOnClickListener {
            val m = moneyValue(amount)
            val s = supplier.selectedItem.toString()
            val debt = db.supplierBalance(branch, s)
            if (m <= 0L) { toast("مبلغ را وارد کن"); return@setOnClickListener }
            if (debt <= 0L) { toast("این فروشنده بدهی فعلی ندارد"); return@setOnClickListener }
            if (m > debt) { toast("بدهی فعلی ${fmt(debt)} تومان است"); return@setOnClickListener }
            if (db.balance(branch, account.selectedItem.toString()) < m) { toast("موجودی حساب کافی نیست"); return@setOnClickListener }
            val row = db.add("SUPPLIER_PAYMENT", branch, "پرداخت بدهی", account.selectedItem.toString(), s, m, 0L)
            uploadRows(listOf(row))
            toast("پرداخت ثبت شد")
            showBranch()
        } }, 56)
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; background = rounded(Color.GRAY, 15); setTextColor(Color.WHITE); setOnClickListener { showBranch() } }, 52)
    }

    private fun showWithdrawal(partner: String) {
        registerRenderer { showWithdrawal(partner) }
        base("برداشت $partner", "شعبه $branch", blueDark, orange)
        addLabel("حساب برداشت")
        val account = spinner(accounts())
        addLabel("مبلغ برداشت")
        val amount = moneyInput()
        addView(amount)
        addView(Button(this).apply { text = "ثبت برداشت $partner"; isAllCaps = false; textSize = 15f; setTextColor(Color.WHITE); background = rounded(orange, 16); setOnClickListener {
            val m = moneyValue(amount)
            if (m <= 0L) { toast("مبلغ را وارد کن"); return@setOnClickListener }
            if (db.balance(branch, account.selectedItem.toString()) < m) { toast("موجودی حساب کافی نیست"); return@setOnClickListener }
            val row = db.add("WITHDRAWAL", branch, "برداشت $partner", account.selectedItem.toString(), partner, m, 0L)
            uploadRows(listOf(row))
            toast("برداشت ثبت شد")
            showBranch()
        } }, 56)
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; background = rounded(Color.GRAY, 15); setTextColor(Color.WHITE); setOnClickListener { showBranch() } }, 52)
    }

    private fun showTransfer() {
        registerRenderer { showTransfer() }
        base("انتقال بین حساب‌ها", "شعبه $branch — بدون تغییر در جمع کل موجودی شعبه", blueDark, blue)
        addLabel("از حساب")
        val from = spinner(accounts())
        addLabel("به حساب")
        val to = spinner(accounts())
        addLabel("مبلغ انتقال")
        val amount = moneyInput()
        addView(amount)
        addView(Button(this).apply { text = "ثبت انتقال"; isAllCaps = false; textSize = 15f; setTextColor(Color.WHITE); background = rounded(blue, 16); setOnClickListener {
            val m = moneyValue(amount)
            if (m <= 0L || from.selectedItem.toString() == to.selectedItem.toString()) { toast("مبدأ، مقصد و مبلغ را درست وارد کن"); return@setOnClickListener }
            if (db.balance(branch, from.selectedItem.toString()) < m) { toast("موجودی حساب مبدأ کافی نیست"); return@setOnClickListener }
            val row = db.add("TRANSFER", branch, "انتقال", from.selectedItem.toString(), to.selectedItem.toString(), m, 0L)
            uploadRows(listOf(row))
            toast("انتقال ثبت شد")
            showBranch()
        } }, 56)
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; background = rounded(Color.GRAY, 15); setTextColor(Color.WHITE); setOnClickListener { showBranch() } }, 52)
    }

    private fun showBalances() {
        registerRenderer { showBalances() }
        base("موجودی حساب‌ها", "شعبه $branch", blueDark, blue)
        accounts().forEach { accountName ->
            val value = db.balance(branch, accountName)
            val card = sectionCard(accountName, "${fmt(value)} تومان", blue)
            root.addView(card, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(5), 0, dp(5)) })
        }
        addLabel("بدهی فروشنده‌ها", red)
        val balances = db.supplierBalances(branch)
        if (balances.isEmpty()) addLabel("بدهی فعلی وجود ندارد") else balances.forEach { (name, value) -> addLabel("$name: ${fmt(value)} تومان", red) }
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; background = rounded(Color.GRAY, 15); setTextColor(Color.WHITE); setOnClickListener { showBranch() } }, 52)
    }

    private fun addHistoryCard(row: Row, filter: String?) {
        val amount = if (row.amount != 0L) row.amount else row.expense
        val color = when (row.type) {
            "EXPENSE" -> red
            "SUPPLIER_PAYMENT" -> green
            "PURCHASE_CREDIT", "PURCHASE_CASH" -> purple
            "WITHDRAWAL" -> orange
            else -> blue
        }
        val card = sectionCard(row.typeLabel, row.desc, color)
        card.addView(TextView(this).apply {
            text = listOfNotNull(row.jalaliDate, row.accountLabel.takeIf { it.isNotBlank() }, row.partyLabel.takeIf { it.isNotBlank() }, "مبلغ: ${fmt(amount)} تومان").joinToString("\n")
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.RIGHT
            setPadding(0, dp(7), 0, 0)
        })
        card.setOnClickListener { showEditDialog(row, filter) }
        root.addView(card, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(5), 0, dp(5)) })
    }

    private fun showHistory(filter: String? = null) {
        registerRenderer { showHistory(filter) }
        base(if (filter == null) "همه تراکنش‌ها" else "تاریخچه $filter", "تاریخ، شرح، حساب و طرف حساب", blueDark, blue)
        val rows = db.rows(filter)
        if (rows.isEmpty()) addLabel("هنوز تراکنشی ثبت نشده") else rows.forEach { addHistoryCard(it, filter) }
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; background = rounded(Color.GRAY, 15); setTextColor(Color.WHITE); setOnClickListener { if (filter == null) showHome() else showBranch() } }, 52)
    }

    private fun showEditDialog(row: Row, filter: String?) {
        AlertDialog.Builder(this)
            .setTitle("ویرایش تراکنش")
            .setItems(arrayOf("ویرایش مبلغ و شرح", "حذف تراکنش", "لغو")) { _, which ->
                when (which) {
                    0 -> editDialog(row, filter)
                    1 -> AlertDialog.Builder(this)
                        .setTitle("حذف تراکنش؟")
                        .setMessage("در فاکتور نقدی، پرداخت مرتبط فروشنده هم با آن حذف می‌شود.")
                        .setNegativeButton("لغو", null)
                        .setPositiveButton("حذف") { _, _ ->
                            db.delete(row.id)
                            uploadPendingDeletes()
                            toast("تراکنش حذف شد")
                            showHistory(filter)
                        }.show()
                }
            }.show()
    }

    private fun editDialog(row: Row, filter: String?) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(10))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val description = field("شرح")
        description.setText(row.desc)
        layout.addView(description, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, 0, 0, dp(6)) })
        val amount = moneyInput()
        amount.setText(fmt(if (row.amount != 0L) row.amount else row.expense))
        layout.addView(amount, LinearLayout.LayoutParams(-1, dp(58)))

        AlertDialog.Builder(this)
            .setTitle("ویرایش")
            .setView(layout)
            .setNegativeButton("لغو", null)
            .setPositiveButton("ذخیره") { _, _ ->
                val newAmount = moneyValue(amount)
                if (newAmount <= 0L) {
                    toast("مبلغ نامعتبر است")
                    return@setPositiveButton
                }
                val result = db.update(row.id, description.text.toString().trim(), newAmount)
                if (!result.success) {
                    toast(result.message)
                    return@setPositiveButton
                }
                uploadRows(result.rows)
                toast("ویرایش شد")
                showHistory(filter)
            }.show()
    }

    private fun showReport() {
        registerRenderer { showReport() }
        base("گزارش کلی", "نمایش یکپارچه وضعیت مالی دو شعبه", blueDark, purple)
        arrayOf("آرایشی", "حرم").forEach { branchName ->
            val sales = db.sumType(branchName, "SALE")
            val expenses = db.sumType(branchName, "EXPENSE")
            val purchases = db.sumPurchases(branchName)
            val cashPurchases = db.sumType(branchName, "PURCHASE_CASH")
            val creditPurchases = db.sumType(branchName, "PURCHASE_CREDIT")
            val allSupplierPayments = db.sumType(branchName, "SUPPLIER_PAYMENT")
            val debtPayments = db.sumDebtPayments(branchName)
            val w1 = db.sumPartnerWithdraw(branchName, "محمدرضا")
            val w2 = db.sumPartnerWithdraw(branchName, "علیرضا")
            val debts = db.supplierBalances(branchName).values.sum()
            val balances = accountsFor(branchName).sumOf { db.balance(branchName, it) }
            val gross = sales - purchases - expenses
            val cashFlow = sales - expenses - cashPurchases - debtPayments - w1 - w2
            val accent = if (branchName == "آرایشی") blue else purple

            val card = sectionCard(branchName, "وضعیت کامل مالی شعبه", accent)
            addReportLine(card, "فروش", sales, green)
            addReportLine(card, "خرید کل", purchases, purple)
            addReportLine(card, "خرید نقدی", cashPurchases, blue)
            addReportLine(card, "خرید نسیه", creditPurchases, purple)
            addReportLine(card, "هزینه", expenses, red)
            addReportLine(card, "کل پرداخت‌های دفتر فروشنده", allSupplierPayments, green)
            addReportLine(card, "پرداخت بدهی عادی فروشنده", debtPayments, green)
            addReportLine(card, "برداشت محمدرضا", w1, orange)
            addReportLine(card, "برداشت علیرضا", w2, orange)
            addReportLine(card, "بدهی فعلی فروشنده‌ها", debts, if (debts > 0) red else green)
            addReportLine(card, "موجودی فعلی حساب‌ها", balances, blue)
            addReportLine(card, "سود ناخالص", gross, if (gross >= 0) green else red)
            addReportLine(card, "جریان نقدی پس از برداشت", cashFlow, if (cashFlow >= 0) green else red)
            root.addView(card, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(7), 0, dp(7)) })
        }

        val note = sectionCard("کنترل مغایرت", "قاعده‌ای که گزارش و موجودی را به هم وصل می‌کند", blue)
        note.addView(TextView(this).apply {
            text = "در فاکتور خرید نقدی، یک فاکتور خرید و یک پرداخت مرتبط فروشنده ثبت می‌شود. پرداخت مرتبط در جریان نقدی دوباره از حساب کم نمی‌شود؛ کاهش حساب فقط از خود خرید نقدی انجام می‌شود. بنابراین دفتر فروشنده، گزارش و موجودی حساب دوباره‌حساب نمی‌شوند."
            textSize = 12.5f
            setTextColor(muted)
            gravity = Gravity.RIGHT
            setPadding(0, dp(7), 0, 0)
        })
        addSectionCard(note)
        addView(Button(this).apply { text = "⬅ برگشت"; isAllCaps = false; background = rounded(Color.GRAY, 15); setTextColor(Color.WHITE); setOnClickListener { showHome() } }, 52)
    }

    private fun addReportLine(parent: LinearLayout, label: String, value: Long, color: Int) {
        parent.addView(TextView(this).apply {
            text = "$label: ${fmt(value)} تومان"
            textSize = 13f
            setTextColor(color)
            gravity = Gravity.RIGHT
            setPadding(0, dp(7), 0, 0)
        })
    }

    private fun signOut() {
        txListener?.remove(); supplierListener?.remove(); categoryListener?.remove()
        syncOk = false
        syncError = null
        currentRenderer = null
        auth.signOut()
        showLogin()
    }

    private fun todayJalali(): String = Jalali.toJalali(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))

    data class UpdateResult(val success: Boolean, val message: String, val rows: List<Row>)

    data class Row(
        val id: Long,
        val date: String,
        val branch: String,
        val type: String,
        val desc: String,
        val account: String?,
        val party: String?,
        val amount: Long,
        val expense: Long,
        val cloudId: String?,
        val linkCloudId: String?,
        val updatedAt: Long,
        val syncState: Int
    ) {
        val displayAmount: Long get() = if (amount != 0L) amount else expense
        val typeLabel: String get() = when (type) {
            "SALE" -> "فروش"
            "EXPENSE" -> "هزینه"
            "PURCHASE_CREDIT" -> "فاکتور خرید نسیه"
            "PURCHASE_CASH" -> "فاکتور خرید نقدی"
            "SUPPLIER_PAYMENT" -> "پرداخت فروشنده"
            "WITHDRAWAL" -> "برداشت"
            "TRANSFER" -> "انتقال"
            else -> type
        }
        val accountLabel: String get() = if (account.isNullOrBlank()) "" else "حساب: $account"
        val partyLabel: String get() = if (party.isNullOrBlank()) "" else "طرف حساب: $party"
        val jalaliDate: String get() = Jalali.toJalali(date)
    }

    class LedgerDb(context: Context) : SQLiteOpenHelper(context, "ledger.db", null, 10) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,branch TEXT,type TEXT,desc TEXT,account TEXT,party TEXT,amount INTEGER DEFAULT 0,expense INTEGER DEFAULT 0,linkCloudId TEXT,cloudId TEXT UNIQUE,updatedAt INTEGER DEFAULT 0,syncState INTEGER DEFAULT 0)")
            db.execSQL("CREATE TABLE suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,branch TEXT,name TEXT,cloudId TEXT,active INTEGER DEFAULT 1,updatedAt INTEGER DEFAULT 0,syncState INTEGER DEFAULT 0,UNIQUE(branch,name))")
            db.execSQL("CREATE TABLE expense_categories(id INTEGER PRIMARY KEY AUTOINCREMENT,branch TEXT,name TEXT,cloudId TEXT,active INTEGER DEFAULT 1,updatedAt INTEGER DEFAULT 0,syncState INTEGER DEFAULT 0,UNIQUE(branch,name))")
            db.execSQL("CREATE TABLE deleted_tx(cloudId TEXT PRIMARY KEY,deletedAt INTEGER)")
            seed(db)
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            if (oldVersion < 3) {
                db.execSQL("CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,branch TEXT,name TEXT,cloudId TEXT,UNIQUE(branch,name))")
                db.execSQL("CREATE TABLE IF NOT EXISTS expense_categories(id INTEGER PRIMARY KEY AUTOINCREMENT,branch TEXT,name TEXT,cloudId TEXT,UNIQUE(branch,name))")
                seed(db)
            }
            if (oldVersion < 4) {
                try { db.execSQL("ALTER TABLE tx ADD COLUMN link_id INTEGER") } catch (_: Exception) {}
            }
            if (oldVersion < 5) {
                try { db.execSQL("ALTER TABLE tx ADD COLUMN cloudId TEXT") } catch (_: Exception) {}
                try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_tx_cloudId ON tx(cloudId)") } catch (_: Exception) {}
            }
            if (oldVersion < 6) {
                try { db.execSQL("ALTER TABLE tx ADD COLUMN linkCloudId TEXT") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE tx ADD COLUMN updatedAt INTEGER DEFAULT 0") } catch (_: Exception) {}
            }
            if (oldVersion < 7) {
                try { db.execSQL("ALTER TABLE suppliers ADD COLUMN cloudId TEXT") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE expense_categories ADD COLUMN cloudId TEXT") } catch (_: Exception) {}
                try { db.execSQL("CREATE TABLE IF NOT EXISTS deleted_tx(cloudId TEXT PRIMARY KEY,deletedAt INTEGER)") } catch (_: Exception) {}
                ensureTransactionCloudIds(db)
                migrateLegacyLinks(db)
            }
            if (oldVersion < 8) {
                try { db.execSQL("ALTER TABLE suppliers ADD COLUMN active INTEGER DEFAULT 1") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE expense_categories ADD COLUMN active INTEGER DEFAULT 1") } catch (_: Exception) {}
            }
            if (oldVersion < 9) {
                try { db.execSQL("ALTER TABLE tx ADD COLUMN syncState INTEGER DEFAULT 0") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE suppliers ADD COLUMN updatedAt INTEGER DEFAULT 0") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE suppliers ADD COLUMN syncState INTEGER DEFAULT 0") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE expense_categories ADD COLUMN updatedAt INTEGER DEFAULT 0") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE expense_categories ADD COLUMN syncState INTEGER DEFAULT 0") } catch (_: Exception) {}
                db.execSQL("UPDATE tx SET syncState=1 WHERE cloudId IS NOT NULL")
                db.execSQL("UPDATE suppliers SET syncState=1")
                db.execSQL("UPDATE expense_categories SET syncState=1")
            }
            if (oldVersion < 10) {
                // Do not force every legacy row dirty again. Existing rows marked dirty above
                // will still be uploaded once; clean rows can be refreshed from Cloud normally.
                try { db.execSQL("CREATE INDEX IF NOT EXISTS idx_tx_cloudId ON tx(cloudId)") } catch (_: Exception) {}
                try { db.execSQL("CREATE INDEX IF NOT EXISTS idx_supplier_cloudId ON suppliers(cloudId)") } catch (_: Exception) {}
                try { db.execSQL("CREATE INDEX IF NOT EXISTS idx_category_cloudId ON expense_categories(cloudId)") } catch (_: Exception) {}
            }
        }

        private fun ensureTransactionCloudIds(database: SQLiteDatabase) {
            val cursor = database.rawQuery("SELECT id FROM tx WHERE cloudId IS NULL OR cloudId=''", null)
            val ids = mutableListOf<Long>()
            while (cursor.moveToNext()) ids += cursor.getLong(0)
            cursor.close()
            ids.forEach { id ->
                val values = ContentValues().apply { put("cloudId", UUID.randomUUID().toString()); put("updatedAt", System.currentTimeMillis()) }
                database.update("tx", values, "id=?", arrayOf(id.toString()))
            }
        }

        private fun migrateLegacyLinks(database: SQLiteDatabase) {
            val cursor = database.rawQuery("SELECT id,link_id FROM tx WHERE link_id IS NOT NULL", null)
            val links = mutableListOf<Pair<Long, Long>>()
            while (cursor.moveToNext()) links += cursor.getLong(0) to cursor.getLong(1)
            cursor.close()
            links.forEach { (id, linkedId) ->
                val linked = database.rawQuery("SELECT cloudId FROM tx WHERE id=?", arrayOf(linkedId.toString()))
                if (linked.moveToFirst()) {
                    val cloudId = linked.getString(0)
                    val values = ContentValues().apply { put("linkCloudId", cloudId) }
                    database.update("tx", values, "id=?", arrayOf(id.toString()))
                }
                linked.close()
            }
        }

        private fun seed(database: SQLiteDatabase) {
            val categories = arrayOf("اجاره", "خرید پلاستیک", "پول برق", "آب", "اینترنت", "حمل‌ونقل", "متفرقه")
            arrayOf("آرایشی", "حرم").forEach { branch -> categories.forEach { addExpenseCategory(branch, it, database) } }
        }

        private fun addExpenseCategory(branch: String, name: String, database: SQLiteDatabase) {
            val values = ContentValues().apply { put("branch", branch); put("name", name) }
            database.insertWithOnConflict("expense_categories", null, values, SQLiteDatabase.CONFLICT_IGNORE)
        }

        fun add(type: String, branch: String, desc: String, account: String?, party: String?, amount: Long, expense: Long, linkCloudId: String? = null): Row {
            val now = System.currentTimeMillis()
            val cloudId = UUID.randomUUID().toString()
            val values = ContentValues().apply {
                put("date", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))
                put("branch", branch)
                put("type", type)
                put("desc", desc)
                if (account == null) putNull("account") else put("account", account)
                if (party == null) putNull("party") else put("party", party)
                put("amount", amount)
                put("expense", expense)
                if (linkCloudId == null) putNull("linkCloudId") else put("linkCloudId", linkCloudId)
                put("cloudId", cloudId)
                put("updatedAt", now)
                put("syncState", 1)
            }
            val id = writableDatabase.insertOrThrow("tx", null, values)
            return rowById(id)!!
        }

        fun rowsWithCloud(): List<Row> = rows(null)

        fun rowById(id: Long): Row? = rows(null).firstOrNull { it.id == id }

        fun rowByCloudId(cloudId: String): Row? = rows(null).firstOrNull { it.cloudId == cloudId }

        fun setCloudId(id: Long, cloudId: String) {
            val values = ContentValues().apply { put("cloudId", cloudId) }
            writableDatabase.update("tx", values, "id=?", arrayOf(id.toString()))
        }

        fun isDirtyCloudId(cloudId: String): Boolean =
            readableDatabase.rawQuery("SELECT syncState FROM tx WHERE cloudId=?", arrayOf(cloudId)).use { c ->
                c.moveToFirst() && c.getInt(0) != 0
            }

        fun shouldApplyCloud(cloudId: String, remoteClientUpdatedAt: Long, remoteUpdatedBy: String, localUid: String): Boolean {
            val local = rowByCloudId(cloudId) ?: return true
            if (local.syncState == 0) return true
            return when {
                remoteClientUpdatedAt > local.updatedAt -> true
                remoteClientUpdatedAt < local.updatedAt -> false
                remoteUpdatedBy.isBlank() -> false
                localUid.isBlank() -> false
                remoteUpdatedBy > localUid -> true
                else -> false
            }
        }

        fun upsertCloud(
            cloudId: String,
            date: String,
            branch: String,
            type: String,
            desc: String,
            account: String?,
            party: String?,
            amount: Long,
            expense: Long,
            linkCloudId: String?,
            updatedAt: Long,
            updatedBy: String
        ) {
            if (tombstoneExists(cloudId)) return
            val local = rowByCloudId(cloudId)
            val values = ContentValues().apply {
                put("date", date); put("branch", branch); put("type", type); put("desc", desc)
                if (account == null) putNull("account") else put("account", account)
                if (party == null) putNull("party") else put("party", party)
                put("amount", amount); put("expense", expense)
                if (linkCloudId == null) putNull("linkCloudId") else put("linkCloudId", linkCloudId)
                put("cloudId", cloudId); put("updatedAt", updatedAt); put("syncState", 0)
            }
            if (local == null) {
                writableDatabase.insertWithOnConflict("tx", null, values, SQLiteDatabase.CONFLICT_IGNORE)
            } else {
                writableDatabase.update("tx", values, "cloudId=?", arrayOf(cloudId))
            }
        }

        private fun tombstoneExists(cloudId: String): Boolean =
            readableDatabase.rawQuery("SELECT 1 FROM deleted_tx WHERE cloudId=? LIMIT 1", arrayOf(cloudId)).use { it.moveToFirst() }

        fun markClean(id: Long) {
            writableDatabase.update("tx", ContentValues().apply { put("syncState", 0) }, "id=?", arrayOf(id.toString()))
        }

        fun dirtyRows(): List<Row> = rowsWithCloud().filter { it.syncState != 0 }

        fun deleteByCloudId(cloudId: String, createTombstone: Boolean) {
            val local = rowByCloudId(cloudId)
            if (local != null && local.linkCloudId != null) {
                writableDatabase.delete("tx", "cloudId=?", arrayOf(local.linkCloudId))
                if (createTombstone) addTombstone(local.linkCloudId)
            }
            writableDatabase.delete("tx", "cloudId=?", arrayOf(cloudId))
            if (createTombstone) addTombstone(cloudId)
        }

        fun tombstones(): List<String> {
            val c = readableDatabase.rawQuery("SELECT cloudId FROM deleted_tx ORDER BY deletedAt", null)
            val out = mutableListOf<String>()
            while (c.moveToNext()) out += c.getString(0)
            c.close()
            return out
        }

        private fun addTombstone(cloudId: String) {
            val values = ContentValues().apply { put("cloudId", cloudId); put("deletedAt", System.currentTimeMillis()) }
            writableDatabase.insertWithOnConflict("deleted_tx", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        }

        fun removeTombstone(cloudId: String) {
            writableDatabase.delete("deleted_tx", "cloudId=?", arrayOf(cloudId))
        }

        fun delete(id: Long): List<String> {
            val row = rowById(id) ?: return emptyList()
            val cloudIds = mutableListOf<String>()
            row.cloudId?.let(cloudIds::add)
            row.linkCloudId?.let(cloudIds::add)
            if (row.linkCloudId == null && row.cloudId != null) {
                rows(null).firstOrNull { it.linkCloudId == row.cloudId }?.cloudId?.let(cloudIds::add)
            }
            val whereIds = mutableListOf(id)
            val linked = if (row.linkCloudId != null) rows(null).firstOrNull { it.cloudId == row.linkCloudId } else rows(null).firstOrNull { it.linkCloudId == row.cloudId }
            linked?.let { whereIds += it.id; it.cloudId?.let(cloudIds::add) }
            whereIds.distinct().forEach { writableDatabase.delete("tx", "id=?", arrayOf(it.toString())) }
            cloudIds.distinct().forEach { addTombstone(it) }
            return cloudIds.distinct()
        }

        fun update(id: Long, desc: String, newAmount: Long): UpdateResult {
            val row = rowById(id) ?: return UpdateResult(false, "تراکنش پیدا نشد", emptyList())
            val validation = validateNewAmount(row, newAmount)
            if (!validation.first) return UpdateResult(false, validation.second, emptyList())
            val now = System.currentTimeMillis()
            val values = ContentValues().apply {
                put("desc", desc)
                if (row.type == "EXPENSE") put("expense", newAmount) else put("amount", newAmount)
                put("updatedAt", now)
                put("syncState", 1)
            }
            writableDatabase.update("tx", values, "id=?", arrayOf(id.toString()))
            val rowsToUpload = mutableListOf<Row>()
            rowById(id)?.let(rowsToUpload::add)

            val linked = when {
                row.linkCloudId != null -> rows(null).firstOrNull { it.cloudId == row.linkCloudId }
                row.cloudId != null -> rows(null).firstOrNull { it.linkCloudId == row.cloudId }
                else -> null
            }
            if (row.type == "PURCHASE_CASH" && linked != null) {
                val paymentValues = ContentValues().apply { put("amount", newAmount); put("updatedAt", now); put("syncState", 1) }
                writableDatabase.update("tx", paymentValues, "id=?", arrayOf(linked.id.toString()))
                rowById(linked.id)?.let(rowsToUpload::add)
            } else if (row.type == "SUPPLIER_PAYMENT" && row.linkCloudId != null && linked != null) {
                val purchaseValues = ContentValues().apply { put("amount", newAmount); put("updatedAt", now); put("syncState", 1) }
                writableDatabase.update("tx", purchaseValues, "id=?", arrayOf(linked.id.toString()))
                rowById(linked.id)?.let(rowsToUpload::add)
            }
            return UpdateResult(true, "ویرایش شد", rowsToUpload.distinctBy { it.cloudId ?: "local-${it.id}" })
        }

        private fun validateNewAmount(row: Row, newAmount: Long): Pair<Boolean, String> {
            if (newAmount <= 0L) return false to "مبلغ باید بیشتر از صفر باشد"
            return when (row.type) {
                "SALE" -> {
                    val available = balance(row.branch, row.account ?: "") + row.amount
                    if (newAmount > available) false to "موجودی حساب برای این ویرایش کافی نیست" else true to ""
                }
                "EXPENSE" -> {
                    val available = balance(row.branch, row.account ?: "") + row.expense
                    if (newAmount > available) false to "موجودی حساب برای این ویرایش کافی نیست" else true to ""
                }
                "WITHDRAWAL" -> {
                    val available = balance(row.branch, row.account ?: "") + row.amount
                    if (newAmount > available) false to "موجودی حساب برای این ویرایش کافی نیست" else true to ""
                }
                "PURCHASE_CASH" -> {
                    val available = balance(row.branch, row.account ?: "") + row.amount
                    if (newAmount > available) false to "موجودی حساب برای این ویرایش کافی نیست" else true to ""
                }
                "SUPPLIER_PAYMENT" -> {
                    if (row.linkCloudId != null) true to "" else {
                        val debtWithoutOldPayment = supplierBalance(row.branch, row.party ?: "") + row.amount
                        val available = balance(row.branch, row.account ?: "") + row.amount
                        when {
                            newAmount > debtWithoutOldPayment -> false to "مبلغ جدید از بدهی فروشنده بیشتر است"
                            newAmount > available -> false to "موجودی حساب برای این ویرایش کافی نیست"
                            else -> true to ""
                        }
                    }
                }
                "TRANSFER" -> {
                    val available = balance(row.branch, row.account ?: "") + row.amount
                    if (newAmount > available) false to "موجودی حساب مبدأ برای این ویرایش کافی نیست" else true to ""
                }
                else -> true to ""
            }
        }

        fun rows(filter: String?): List<Row> {
            val sql = if (filter == null) {
                "SELECT id,date,branch,type,desc,account,party,amount,expense,cloudId,linkCloudId,updatedAt,syncState FROM tx ORDER BY id DESC"
            } else {
                "SELECT id,date,branch,type,desc,account,party,amount,expense,cloudId,linkCloudId,updatedAt,syncState FROM tx WHERE branch=? ORDER BY id DESC"
            }
            val cursor = if (filter == null) readableDatabase.rawQuery(sql, null) else readableDatabase.rawQuery(sql, arrayOf(filter))
            val output = mutableListOf<Row>()
            while (cursor.moveToNext()) {
                output += Row(
                    cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4),
                    cursor.getString(5), cursor.getString(6), cursor.getLong(7), cursor.getLong(8), cursor.getString(9), cursor.getString(10), cursor.getLong(11), cursor.getInt(12)
                )
            }
            cursor.close()
            return output
        }

        fun balance(branch: String, account: String): Long {
            var value = 0L
            val cursor = readableDatabase.rawQuery("SELECT type,account,party,amount,expense FROM tx WHERE branch=?", arrayOf(branch))
            while (cursor.moveToNext()) {
                when (cursor.getString(0)) {
                    "SALE" -> if (cursor.getString(1) == account) value += cursor.getLong(3)
                    "EXPENSE", "WITHDRAWAL", "PURCHASE_CASH", "SUPPLIER_PAYMENT" -> if (cursor.getString(1) == account) value -= if (cursor.getString(0) == "EXPENSE") cursor.getLong(4) else cursor.getLong(3)
                    "TRANSFER" -> {
                        if (cursor.getString(1) == account) value -= cursor.getLong(3)
                        if (cursor.getString(2) == account) value += cursor.getLong(3)
                    }
                }
            }
            cursor.close()
            return value
        }

        fun ensureSupplier(branch: String, name: String, cloudId: String? = null, active: Boolean = true, updatedAt: Long = System.currentTimeMillis(), dirty: Boolean = true) {
            val values = ContentValues().apply {
                put("branch", branch); put("name", name); put("active", if (active) 1 else 0); put("updatedAt", updatedAt)
                if (cloudId != null) put("cloudId", cloudId)
                put("syncState", if (dirty) 1 else 0)
            }
            val inserted = writableDatabase.insertWithOnConflict("suppliers", null, values, SQLiteDatabase.CONFLICT_IGNORE)
            if (inserted == -1L) {
                if (cloudId != null) writableDatabase.update("suppliers", values, "branch=? AND name=?", arrayOf(branch, name))
                else writableDatabase.update("suppliers", values, "branch=? AND name=?", arrayOf(branch, name))
            }
        }

        fun supplierCloudId(branch: String, name: String): String? = readableDatabase.rawQuery(
            "SELECT cloudId FROM suppliers WHERE branch=? AND name=?", arrayOf(branch, name)
        ).use { c -> if (c.moveToFirst()) c.getString(0) else null }

        fun setSupplierCloudId(branch: String, name: String, cloudId: String) {
            writableDatabase.update("suppliers", ContentValues().apply { put("cloudId", cloudId) }, "branch=? AND name=?", arrayOf(branch, name))
        }

        fun supplierUpdatedAt(branch: String, name: String): Long = readableDatabase.rawQuery(
            "SELECT updatedAt FROM suppliers WHERE branch=? AND name=?", arrayOf(branch, name)
        ).use { c -> if (c.moveToFirst()) c.getLong(0) else System.currentTimeMillis() }

        fun isSupplierDirty(branch: String, name: String): Boolean = readableDatabase.rawQuery(
            "SELECT syncState FROM suppliers WHERE branch=? AND name=?", arrayOf(branch, name)
        ).use { c -> c.moveToFirst() && c.getInt(0) != 0 }

        fun shouldApplySupplierCloud(branch: String, name: String, remoteUpdatedAt: Long): Boolean {
            val c = readableDatabase.rawQuery("SELECT updatedAt,syncState FROM suppliers WHERE branch=? AND name=?", arrayOf(branch, name))
            if (!c.moveToFirst()) { c.close(); return true }
            val localUpdatedAt = c.getLong(0)
            val dirty = c.getInt(1) != 0
            c.close()
            if (!dirty) return true
            if (remoteUpdatedAt > localUpdatedAt) return true
            if (remoteUpdatedAt < localUpdatedAt) return false
            // Same millisecond: keep the local edit deterministically.
            return false
        }

        fun dirtySuppliers(branch: String): List<String> = readableDatabase.rawQuery(
            "SELECT name FROM suppliers WHERE branch=? AND syncState!=0 ORDER BY name", arrayOf(branch)
        ).use { c -> val out=mutableListOf<String>(); while(c.moveToNext()) out+=c.getString(0); out }

        fun markSupplierClean(branch: String, name: String) {
            writableDatabase.update("suppliers", ContentValues().apply { put("syncState", 0) }, "branch=? AND name=?", arrayOf(branch, name))
        }

        fun suppliers(branch: String): List<String> {
            val c = readableDatabase.rawQuery("SELECT name FROM suppliers WHERE branch=? ORDER BY name", arrayOf(branch))
            val out = mutableListOf<String>(); while (c.moveToNext()) out += c.getString(0); c.close(); return out
        }

        fun activeSuppliers(branch: String): List<String> {
            val c = readableDatabase.rawQuery("SELECT name FROM suppliers WHERE branch=? AND active=1 ORDER BY name", arrayOf(branch))
            val out = mutableListOf<String>(); while (c.moveToNext()) out += c.getString(0); c.close(); return out
        }

        fun supplierActive(branch: String, name: String): Boolean = readableDatabase.rawQuery("SELECT active FROM suppliers WHERE branch=? AND name=?", arrayOf(branch, name)).use { c ->
            c.moveToFirst() && c.getInt(0) != 0
        }

        fun toggleSupplier(branch: String, name: String): Boolean {
            val next = !supplierActive(branch, name)
            writableDatabase.update("suppliers", ContentValues().apply { put("active", if (next) 1 else 0); put("updatedAt", System.currentTimeMillis()); put("syncState", 1) }, "branch=? AND name=?", arrayOf(branch, name))
            return next
        }

        fun supplierBalance(branch: String, supplier: String): Long {
            var value = 0L
            val c = readableDatabase.rawQuery("SELECT type,amount FROM tx WHERE branch=? AND party=?", arrayOf(branch, supplier))
            while (c.moveToNext()) {
                when (c.getString(0)) {
                    "PURCHASE_CREDIT", "PURCHASE_CASH" -> value += c.getLong(1)
                    "SUPPLIER_PAYMENT" -> value -= c.getLong(1)
                }
            }
            c.close(); return value
        }

        fun supplierPurchases(branch: String, supplier: String): Long = sumByQuery(
            "SELECT COALESCE(SUM(amount),0) FROM tx WHERE branch=? AND party=? AND type IN ('PURCHASE_CREDIT','PURCHASE_CASH')",
            arrayOf(branch, supplier)
        )

        fun supplierPayments(branch: String, supplier: String): Long = sumByQuery(
            "SELECT COALESCE(SUM(amount),0) FROM tx WHERE branch=? AND party=? AND type='SUPPLIER_PAYMENT'",
            arrayOf(branch, supplier)
        )

        fun supplierBalances(branch: String): Map<String, Long> {
            val result = mutableMapOf<String, Long>()
            val c = readableDatabase.rawQuery("SELECT party,type,amount FROM tx WHERE branch=? AND party IS NOT NULL", arrayOf(branch))
            while (c.moveToNext()) {
                val party = c.getString(0); val amount = c.getLong(2)
                result[party] = when (c.getString(1)) {
                    "PURCHASE_CREDIT", "PURCHASE_CASH" -> (result[party] ?: 0L) + amount
                    "SUPPLIER_PAYMENT" -> (result[party] ?: 0L) - amount
                    else -> result[party] ?: 0L
                }
            }
            c.close(); return result.filterValues { it != 0L }
        }

        fun hasSupplierTransactions(branch: String, supplier: String): Boolean =
            readableDatabase.rawQuery("SELECT 1 FROM tx WHERE branch=? AND party=? LIMIT 1", arrayOf(branch, supplier)).use { it.moveToFirst() }

        fun renameSupplier(branch: String, oldName: String, newName: String): String? {
            val oldCloud = readableDatabase.rawQuery("SELECT cloudId FROM suppliers WHERE branch=? AND name=?", arrayOf(branch, oldName)).use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
            val now = System.currentTimeMillis()
            writableDatabase.update("suppliers", ContentValues().apply { put("name", newName); put("updatedAt", now); put("syncState", 1) }, "branch=? AND name=?", arrayOf(branch, oldName))
            writableDatabase.update("tx", ContentValues().apply { put("party", newName); put("updatedAt", now); put("syncState", 1) }, "branch=? AND party=?", arrayOf(branch, oldName))
            return oldCloud
        }

        fun deleteSupplier(branch: String, name: String): String? {
            val cloudId = readableDatabase.rawQuery("SELECT cloudId FROM suppliers WHERE branch=? AND name=?", arrayOf(branch, name)).use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
            writableDatabase.delete("suppliers", "branch=? AND name=?", arrayOf(branch, name))
            return cloudId
        }

        fun deleteSupplierByCloudId(cloudId: String) {
            writableDatabase.delete("suppliers", "cloudId=?", arrayOf(cloudId))
        }

        fun renameExpenseCategory(branch: String, oldName: String, newName: String): String? {
            val oldCloud = readableDatabase.rawQuery("SELECT cloudId FROM expense_categories WHERE branch=? AND name=?", arrayOf(branch, oldName)).use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
            val now = System.currentTimeMillis()
            writableDatabase.update("expense_categories", ContentValues().apply { put("name", newName); put("updatedAt", now); put("syncState", 1) }, "branch=? AND name=?", arrayOf(branch, oldName))
            val cursor = writableDatabase.rawQuery("SELECT id,desc FROM tx WHERE branch=? AND type='EXPENSE' AND (desc=? OR desc LIKE ?)", arrayOf(branch, oldName, "$oldName:%"))
            val updates = mutableListOf<Pair<Long,String>>()
            while (cursor.moveToNext()) {
                val id = cursor.getLong(0)
                val desc = cursor.getString(1)
                val newDesc = if (desc == oldName) newName else newName + desc.removePrefix(oldName)
                updates += id to newDesc
            }
            cursor.close()
            updates.forEach { (id, desc) ->
                writableDatabase.update("tx", ContentValues().apply { put("desc", desc); put("updatedAt", now); put("syncState", 1) }, "id=?", arrayOf(id.toString()))
            }
            return oldCloud
        }

        fun hasExpenseCategoryTransactions(branch: String, name: String): Boolean =
            readableDatabase.rawQuery("SELECT 1 FROM tx WHERE branch=? AND type='EXPENSE' AND (desc=? OR desc LIKE ?) LIMIT 1", arrayOf(branch, name, "$name:%")).use { it.moveToFirst() }

        fun deleteExpenseCategory(branch: String, name: String): String? {
            val cloudId = readableDatabase.rawQuery("SELECT cloudId FROM expense_categories WHERE branch=? AND name=?", arrayOf(branch, name)).use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
            writableDatabase.delete("expense_categories", "branch=? AND name=?", arrayOf(branch, name))
            return cloudId
        }

        fun deleteExpenseCategoryByCloudId(cloudId: String) {
            writableDatabase.delete("expense_categories", "cloudId=?", arrayOf(cloudId))
        }

        fun expenseCategories(branch: String): List<String> {
            val c = readableDatabase.rawQuery("SELECT name FROM expense_categories WHERE branch=? ORDER BY id", arrayOf(branch))
            val out = mutableListOf<String>(); while (c.moveToNext()) out += c.getString(0); c.close(); return out
        }

        fun activeExpenseCategories(branch: String): List<String> {
            val c = readableDatabase.rawQuery("SELECT name FROM expense_categories WHERE branch=? AND active=1 ORDER BY id", arrayOf(branch))
            val out = mutableListOf<String>(); while (c.moveToNext()) out += c.getString(0); c.close(); return out
        }

        fun categoryActive(branch: String, name: String): Boolean = readableDatabase.rawQuery("SELECT active FROM expense_categories WHERE branch=? AND name=?", arrayOf(branch, name)).use { c ->
            c.moveToFirst() && c.getInt(0) != 0
        }

        fun toggleExpenseCategory(branch: String, name: String): Boolean {
            val next = !categoryActive(branch, name)
            writableDatabase.update("expense_categories", ContentValues().apply { put("active", if (next) 1 else 0); put("updatedAt", System.currentTimeMillis()); put("syncState", 1) }, "branch=? AND name=?", arrayOf(branch, name))
            return next
        }

        fun addExpenseCategory(branch: String, name: String, cloudId: String? = null, active: Boolean = true, updatedAt: Long = System.currentTimeMillis(), dirty: Boolean = true) {
            addExpenseCategory(branch, name, writableDatabase)
            val values = ContentValues().apply { put("active", if (active) 1 else 0); put("updatedAt", updatedAt); put("syncState", if (dirty) 1 else 0) }
            if (cloudId != null) values.put("cloudId", cloudId)
            writableDatabase.update("expense_categories", values, "branch=? AND name=?", arrayOf(branch, name))
        }

        fun categoryCloudId(branch: String, name: String): String? = readableDatabase.rawQuery(
            "SELECT cloudId FROM expense_categories WHERE branch=? AND name=?", arrayOf(branch, name)
        ).use { c -> if (c.moveToFirst()) c.getString(0) else null }

        fun setCategoryCloudId(branch: String, name: String, cloudId: String) {
            writableDatabase.update("expense_categories", ContentValues().apply { put("cloudId", cloudId) }, "branch=? AND name=?", arrayOf(branch, name))
        }

        fun categoryUpdatedAt(branch: String, name: String): Long = readableDatabase.rawQuery(
            "SELECT updatedAt FROM expense_categories WHERE branch=? AND name=?", arrayOf(branch, name)
        ).use { c -> if (c.moveToFirst()) c.getLong(0) else System.currentTimeMillis() }

        fun isCategoryDirty(branch: String, name: String): Boolean = readableDatabase.rawQuery(
            "SELECT syncState FROM expense_categories WHERE branch=? AND name=?", arrayOf(branch, name)
        ).use { c -> c.moveToFirst() && c.getInt(0) != 0 }

        fun shouldApplyCategoryCloud(branch: String, name: String, remoteUpdatedAt: Long): Boolean {
            val c = readableDatabase.rawQuery("SELECT updatedAt,syncState FROM expense_categories WHERE branch=? AND name=?", arrayOf(branch, name))
            if (!c.moveToFirst()) { c.close(); return true }
            val localUpdatedAt = c.getLong(0)
            val dirty = c.getInt(1) != 0
            c.close()
            if (!dirty) return true
            if (remoteUpdatedAt > localUpdatedAt) return true
            if (remoteUpdatedAt < localUpdatedAt) return false
            // Same millisecond: keep the local edit deterministically.
            return false
        }

        fun dirtyCategories(branch: String): List<String> = readableDatabase.rawQuery(
            "SELECT name FROM expense_categories WHERE branch=? AND syncState!=0 ORDER BY id", arrayOf(branch)
        ).use { c -> val out=mutableListOf<String>(); while(c.moveToNext()) out+=c.getString(0); out }

        fun markCategoryClean(branch: String, name: String) {
            writableDatabase.update("expense_categories", ContentValues().apply { put("syncState", 0) }, "branch=? AND name=?", arrayOf(branch, name))
        }

        fun sumDebtPayments(branch: String): Long = sumByQuery(
            "SELECT COALESCE(SUM(amount),0) FROM tx WHERE branch=? AND type='SUPPLIER_PAYMENT' AND linkCloudId IS NULL",
            arrayOf(branch)
        )

        fun sumPurchases(branch: String): Long = sumByQuery(
            "SELECT COALESCE(SUM(amount),0) FROM tx WHERE branch=? AND type IN ('PURCHASE_CREDIT','PURCHASE_CASH')",
            arrayOf(branch)
        )

        fun sumType(branch: String, type: String): Long = sumByQuery(
            "SELECT COALESCE(SUM(CASE WHEN type='EXPENSE' THEN expense ELSE amount END),0) FROM tx WHERE branch=? AND type=?",
            arrayOf(branch, type)
        )

        fun sumPartnerWithdraw(branch: String, partner: String): Long = sumByQuery(
            "SELECT COALESCE(SUM(amount),0) FROM tx WHERE branch=? AND type='WITHDRAWAL' AND party=?",
            arrayOf(branch, partner)
        )

        private fun sumByQuery(sql: String, args: Array<String>): Long {
            val c = readableDatabase.rawQuery(sql, args)
            c.moveToFirst(); val value = c.getLong(0); c.close(); return value
        }
    }

    object Jalali {
        fun toJalali(gregorian: String): String = try {
            val parts = gregorian.substring(0, 10).split("-").map { it.toInt() }
            val converted = convert(parts[0], parts[1], parts[2])
            String.format(Locale.US, "%04d/%02d/%02d %s", converted[0], converted[1], converted[2], gregorian.substring(11))
        } catch (_: Exception) { gregorian }

        private fun convert(gy: Int, gm: Int, gd: Int): IntArray {
            // Correct Gregorian -> Jalali conversion. The previous implementation
            // counted the Gregorian month length incorrectly and could be 4 days ahead.
            val gdm = intArrayOf(0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
            var jy = if (gy > 1600) 979 else 0
            var gyear = if (gy > 1600) gy - 1600 else gy - 621
            val gy2 = if (gm > 2) gyear + 1 else gyear
            var days = 365 * gyear + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 - 80 + gd
            for (m in 0 until gm) days += gdm[m]
            jy += 33 * (days / 12053)
            var r = days % 12053
            jy += 4 * (r / 1461)
            r %= 1461
            if (r > 365) {
                jy += (r - 1) / 365
                r = (r - 1) % 365
            }
            val jm = if (r < 186) 1 + r / 31 else 7 + (r - 186) / 30
            val jd = 1 + if (r < 186) r % 31 else (r - 186) % 30
            return intArrayOf(jy, jm, jd)
        }
    }
}
