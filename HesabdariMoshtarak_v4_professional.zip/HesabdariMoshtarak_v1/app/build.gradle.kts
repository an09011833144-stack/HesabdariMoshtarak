plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.hesabdari.moshtarak"; compileSdk = 35
    defaultConfig { applicationId = "com.hesabdari.moshtarak"; minSdk = 23; targetSdk = 35; versionCode = 2; versionName = "1.1" }
}

kotlin { jvmToolchain(17) }
