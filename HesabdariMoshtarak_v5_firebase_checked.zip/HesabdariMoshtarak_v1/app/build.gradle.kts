plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}
android { namespace="com.hesabdari.moshtarak"; compileSdk=35
    defaultConfig { applicationId="com.hesabdari.moshtarak"; minSdk=23; targetSdk=35; versionCode=5; versionName="2.0-firebase" }
}
kotlin { jvmToolchain(17) }
dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.10.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
}
