# نسخه Firebase

- Email/Password در Firebase Authentication فعال باشد.
- Firestore روی Production Mode باشد.
- Rules فایل `firestore.rules` را در بخش Rules قرار بده و Publish کن.
- `google-services.json` داخل پوشه `app/` است.
- برنامه پس از ورود، تراکنش‌ها، فروشنده‌ها و دسته‌های هزینه را بین دو گوشی همگام می‌کند.
- برای ساخت APK از Java 17 و Gradle 8.7 استفاده شده است.
